<?php
/**
 * NDS Paper — Global configuration
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('APP_NAME', 'NDS Paper');
define('BASE_URL', '/');                       // change if hosted in a sub-folder
define('UPLOAD_DIR', __DIR__ . '/../uploads');  // logos, source images
define('PAPER_DIR', __DIR__ . '/../generated'); // generated PDFs
define('COST_PER_DOWNLOAD', 10);                // credits deducted per final PDF download

// Make sure runtime folders exist
foreach ([UPLOAD_DIR, UPLOAD_DIR . '/logos', UPLOAD_DIR . '/pages', PAPER_DIR] as $dir) {
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
}

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
