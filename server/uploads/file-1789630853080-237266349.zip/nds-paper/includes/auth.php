<?php
/**
 * NDS Paper — Authentication helpers
 */

function current_user(): ?array {
    return $_SESSION['user'] ?? null;
}

function is_logged_in(): bool {
    return isset($_SESSION['user']);
}

function is_admin(): bool {
    return is_logged_in() && $_SESSION['user']['role'] === 'admin';
}

/** Redirect to login if not authenticated. */
function require_login(): void {
    if (!is_logged_in()) {
        header('Location: ' . BASE_URL . 'auth/login.php');
        exit;
    }
}

/** Redirect non-admins away from admin-only pages. */
function require_admin(): void {
    require_login();
    if (!is_admin()) {
        header('Location: ' . BASE_URL . 'user/dashboard.php');
        exit;
    }
}

/** Refresh the session copy of the user row (call after credit/detail changes). */
function refresh_session_user(PDO $pdo): void {
    if (!is_logged_in()) return;
    $stmt = $pdo->prepare('SELECT id, name, email, role, institute_name, credits, status FROM users WHERE id = ?');
    $stmt->execute([$_SESSION['user']['id']]);
    $row = $stmt->fetch();
    if ($row) {
        $_SESSION['user'] = $row;
    }
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_check(?string $token): bool {
    return $token !== null && hash_equals($_SESSION['csrf'] ?? '', $token);
}
