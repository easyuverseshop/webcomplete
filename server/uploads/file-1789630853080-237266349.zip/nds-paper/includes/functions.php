<?php
/**
 * NDS Paper — Shared helper functions
 */

/** Adjust a user's credit balance and write a ledger row. $amount can be +ve or -ve. */
function adjust_credits(PDO $pdo, int $userId, int $amount, string $reason, ?int $adminId = null): bool {
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare('SELECT credits FROM users WHERE id = ? FOR UPDATE');
        $stmt->execute([$userId]);
        $user = $stmt->fetch();
        if (!$user) { $pdo->rollBack(); return false; }

        $newBalance = $user['credits'] + $amount;
        if ($newBalance < 0) { $pdo->rollBack(); return false; } // insufficient credits

        $pdo->prepare('UPDATE users SET credits = ? WHERE id = ?')->execute([$newBalance, $userId]);
        $pdo->prepare('INSERT INTO credit_transactions (user_id, amount, reason, balance_after, created_by) VALUES (?,?,?,?,?)')
            ->execute([$userId, $amount, $reason, $newBalance, $adminId]);

        $pdo->commit();
        return true;
    } catch (Exception $e) {
        $pdo->rollBack();
        return false;
    }
}

function log_activity(PDO $pdo, ?int $userId, string $action): void {
    $pdo->prepare('INSERT INTO activity_log (user_id, action) VALUES (?, ?)')->execute([$userId, $action]);
}

/** Templates visible to a given user: all templates if no explicit access rows exist for them, else only assigned ones. */
function templates_for_user(PDO $pdo, int $userId): array {
    $stmt = $pdo->prepare(
        "SELECT t.* FROM templates t
         WHERE t.status = 'active'
           AND (
             NOT EXISTS (SELECT 1 FROM template_access WHERE template_id = t.id)
             OR EXISTS (SELECT 1 FROM template_access WHERE template_id = t.id AND user_id = ?)
           )
         ORDER BY t.name"
    );
    $stmt->execute([$userId]);
    return $stmt->fetchAll();
}

function h(?string $s): string {
    return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8');
}

function credits_used_this_month(PDO $pdo, int $userId): int {
    $stmt = $pdo->prepare(
        "SELECT COALESCE(SUM(-amount),0) AS used FROM credit_transactions
         WHERE user_id = ? AND amount < 0 AND MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())"
    );
    $stmt->execute([$userId]);
    return (int) $stmt->fetch()['used'];
}
