-- =========================================================
-- Migration: add visual header-designer support
-- Run this if you already imported the original schema.sql
-- =========================================================
ALTER TABLE templates
  ADD COLUMN header_layout LONGTEXT DEFAULT NULL AFTER header_height_mm;
