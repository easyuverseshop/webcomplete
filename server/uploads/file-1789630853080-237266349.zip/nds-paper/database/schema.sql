-- =========================================================
-- NDS Paper — Database Schema
-- Import this file into MySQL/MariaDB before using the app.
--   mysql -u root -p < schema.sql
-- =========================================================

CREATE DATABASE IF NOT EXISTS nds_paper CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE nds_paper;

-- ---------------------------------------------------------
-- Users (admins + institute/reseller users)
-- ---------------------------------------------------------
CREATE TABLE users (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(120)  NOT NULL,
    email           VARCHAR(150)  NOT NULL UNIQUE,
    phone           VARCHAR(20)   DEFAULT NULL,
    password_hash   VARCHAR(255)  NOT NULL,
    role            ENUM('admin','user') NOT NULL DEFAULT 'user',
    institute_name  VARCHAR(150)  DEFAULT NULL,
    credits         INT           NOT NULL DEFAULT 0,
    status          ENUM('active','blocked') NOT NULL DEFAULT 'active',
    created_at      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Seed a default admin (password: Admin@123 — change immediately after first login)
INSERT INTO users (name, email, password_hash, role, institute_name, credits)
VALUES ('Super Admin', 'admin@ndspaper.com',
'$2y$10$8pQeYVvKq0T1o0X6X1o0XeQeYVvKq0T1o0X6X1o0XeQeYVvKq0T1o', -- placeholder, replaced by setup.php on first run
'admin', 'NDS Paper HQ', 0);

-- ---------------------------------------------------------
-- Templates (letterhead / header definitions created by admin)
-- ---------------------------------------------------------
CREATE TABLE templates (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(120)  NOT NULL,
    institute_name  VARCHAR(150)  NOT NULL,
    address_line1   VARCHAR(200)  DEFAULT NULL,
    address_line2   VARCHAR(200)  DEFAULT NULL,
    phone           VARCHAR(40)   DEFAULT NULL,
    logo_path       VARCHAR(255)  DEFAULT NULL,
    accent_color    VARCHAR(10)   DEFAULT '#0F1B2D',
    header_height_mm INT          NOT NULL DEFAULT 35,
    header_layout   LONGTEXT      DEFAULT NULL,   -- JSON: exact position/size of logo + text, drawn in admin's header designer
    created_by      INT UNSIGNED  NOT NULL,
    status          ENUM('active','archived') NOT NULL DEFAULT 'active',
    created_at      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Which users are allowed to use which templates (admin assigns; empty = all users)
CREATE TABLE template_access (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    template_id INT UNSIGNED NOT NULL,
    user_id     INT UNSIGNED NOT NULL,
    FOREIGN KEY (template_id) REFERENCES templates(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY uniq_template_user (template_id, user_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Question papers created by users
-- ---------------------------------------------------------
CREATE TABLE papers (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id         INT UNSIGNED NOT NULL,
    template_id     INT UNSIGNED NOT NULL,
    title           VARCHAR(150) DEFAULT 'Untitled Question Paper',
    page_size       VARCHAR(10)  NOT NULL DEFAULT 'A4',
    page_count      INT UNSIGNED NOT NULL DEFAULT 1,
    canvas_json     LONGTEXT     DEFAULT NULL,   -- serialized editor state (pages, images, transforms)
    pdf_path        VARCHAR(255) DEFAULT NULL,
    credits_used    INT UNSIGNED NOT NULL DEFAULT 0,
    status          ENUM('draft','downloaded') NOT NULL DEFAULT 'draft',
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (template_id) REFERENCES templates(id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Credit ledger — every add / revert / spend is logged
-- ---------------------------------------------------------
CREATE TABLE credit_transactions (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id     INT UNSIGNED NOT NULL,
    amount      INT NOT NULL,                 -- positive = credited, negative = debited
    reason      VARCHAR(200) NOT NULL,
    balance_after INT NOT NULL,
    created_by  INT UNSIGNED DEFAULT NULL,     -- admin id if manual action, NULL if system (download)
    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Simple activity log (for admin visibility)
-- ---------------------------------------------------------
CREATE TABLE activity_log (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id     INT UNSIGNED DEFAULT NULL,
    action      VARCHAR(200) NOT NULL,
    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
