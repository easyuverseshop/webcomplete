<?php
require_once __DIR__ . '/../config/config.php';
require_login();
if (is_admin()) { header('Location: ../admin/dashboard.php'); exit; }
refresh_session_user($pdo);
$me = current_user();

$totalPapers = $pdo->prepare("SELECT COUNT(*) c FROM papers WHERE user_id = ? AND status='downloaded'");
$totalPapers->execute([$me['id']]);
$totalPapers = (int) $totalPapers->fetch()['c'];

$templates = templates_for_user($pdo, $me['id']);
$usedThisMonth = credits_used_this_month($pdo, $me['id']);

$recent = $pdo->prepare("SELECT p.*, t.name AS tpl_name FROM papers p JOIN templates t ON t.id=p.template_id WHERE p.user_id=? ORDER BY p.updated_at DESC LIMIT 8");
$recent->execute([$me['id']]);
$recent = $recent->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard — NDS Paper</title>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:wght@500;600;700&family=Inter:wght@400;500;600;700&family=IBM+Plex+Mono:wght@500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="assets/user.css">
</head>
<body>
<div class="app-shell">
  <aside class="sidebar">
    <div class="brand"><div class="mark">NDS <span style="color:var(--gold)">Paper</span></div></div>
    <nav class="side-nav">
      <a href="dashboard.php" class="active">&#9635; Dashboard</a>
      <a href="editor.php">&#9998; Create new paper</a>
    </nav>
    <div class="who">
      Signed in as<br><strong style="color:#fff;"><?= h($me['name']) ?></strong><br>
      <small><?= h($me['institute_name']) ?></small><br>
      <a href="../auth/logout.php">Log out</a>
    </div>
  </aside>

  <main class="main">
    <div class="topbar">
      <div><h1>Welcome back, <?= h(explode(' ', $me['name'])[0]) ?></h1><div class="sub"><?= h($me['institute_name']) ?></div></div>
      <a href="editor.php" class="btn btn-stamp">+ Create new question paper</a>
    </div>

    <div class="credit-banner">
      <div><div class="label">Credits available</div><div class="amt"><?= (int)$me['credits'] ?></div></div>
      <div><div class="label">Used this month</div><div class="amt" style="color:#fff;font-size:1.4rem;"><?= $usedThisMonth ?></div></div>
      <div><div class="label">Papers downloaded</div><div class="amt" style="color:#fff;font-size:1.4rem;"><?= $totalPapers ?></div></div>
      <div><div class="label">Templates available</div><div class="amt" style="color:#fff;font-size:1.4rem;"><?= count($templates) ?></div></div>
    </div>

    <div class="panel">
      <div class="panel-head"><h2>Your templates</h2><a href="editor.php" style="font-size:.85rem;color:var(--stamp);">Start a paper &rarr;</a></div>
      <div class="panel-body">
        <?php if ($templates): ?>
        <div class="tpl-grid">
          <?php foreach ($templates as $t): ?>
          <a class="tpl-card" href="editor.php?template=<?= $t['id'] ?>" style="display:block;color:inherit;">
            <img src="<?= $t['logo_path'] ? '../' . h($t['logo_path']) : '../assets/img/logo-placeholder.png' ?>" alt="">
            <h4><?= h($t['name']) ?></h4>
            <p><?= h($t['institute_name']) ?></p>
          </a>
          <?php endforeach; ?>
        </div>
        <?php else: ?>
          <p style="color:#6b7280;">No templates have been assigned to you yet. Ask your administrator to create one.</p>
        <?php endif; ?>
      </div>
    </div>

    <div class="panel">
      <div class="panel-head"><h2>Recent papers</h2></div>
      <div class="panel-body">
        <ul class="recent-list">
          <?php foreach ($recent as $p): ?>
          <li>
            <a href="editor.php?paper=<?= $p['id'] ?>" style="color:inherit;text-decoration:none;">
              <?= h($p['title']) ?> <small style="color:#6b7280;">&middot; <?= h($p['tpl_name']) ?> &middot; <?= $p['page_count'] ?> pages</small>
            </a>
            <span class="pill <?= $p['status']==='downloaded' ? 'pill-active':'pill-blocked' ?>"><?= h($p['status']) ?></span>
          </li>
          <?php endforeach; ?>
          <?php if (!$recent): ?><li style="color:#6b7280;">You haven't created any papers yet.</li><?php endif; ?>
        </ul>
      </div>
    </div>
  </main>
</div>
</body>
</html>
