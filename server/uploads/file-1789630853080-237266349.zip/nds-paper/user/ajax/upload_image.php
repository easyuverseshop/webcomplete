<?php
require_once __DIR__ . '/../../config/config.php';
header('Content-Type: application/json');

if (!is_logged_in() || is_admin()) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'Not authorized']);
    exit;
}

$user = current_user();

if (empty($_POST['csrf']) || !csrf_check($_POST['csrf'])) {
    echo json_encode(['ok' => false, 'error' => 'Session expired. Please refresh the page and try again.']);
    exit;
}

if (empty($_FILES['image']['name'])) {
    echo json_encode(['ok' => false, 'error' => 'No image received.']);
    exit;
}

$ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
if (!in_array($ext, ['png', 'jpg', 'jpeg', 'webp'])) {
    echo json_encode(['ok' => false, 'error' => 'Please upload a PNG, JPG or WEBP image.']);
    exit;
}
if ($_FILES['image']['size'] > 15 * 1024 * 1024) {
    echo json_encode(['ok' => false, 'error' => 'That image is larger than 15MB — please use a smaller file.']);
    exit;
}

$userDir = UPLOAD_DIR . '/pages/' . $user['id'];
if (!is_dir($userDir)) {
    mkdir($userDir, 0775, true);
}

$fname = 'img_' . time() . '_' . bin2hex(random_bytes(5)) . '.' . $ext;
if (!move_uploaded_file($_FILES['image']['tmp_name'], $userDir . '/' . $fname)) {
    echo json_encode(['ok' => false, 'error' => 'Could not save the uploaded image.']);
    exit;
}

// Relative to the app root — the client (in /user/) prefixes it with '../' same as logo_path.
$relative = 'uploads/pages/' . $user['id'] . '/' . $fname;
echo json_encode(['ok' => true, 'url' => $relative]);
