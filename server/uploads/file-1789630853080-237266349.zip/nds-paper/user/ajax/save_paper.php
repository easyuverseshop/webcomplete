<?php
require_once __DIR__ . '/../../config/config.php';
header('Content-Type: application/json');

if (!is_logged_in() || is_admin()) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'Not authorized']);
    exit;
}

$raw = file_get_contents('php://input');
$data = json_decode($raw, true) ?? [];

if (!csrf_check($data['csrf'] ?? null)) {
    echo json_encode(['ok' => false, 'error' => 'Session expired. Please refresh the page and try again.']);
    exit;
}

$user = current_user();
$id = (int) ($data['id'] ?? 0);
$title = trim($data['title'] ?? 'Untitled Question Paper');
$templateId = (int) ($data['template_id'] ?? 0);
$pageSize = in_array($data['page_size'] ?? 'A4', ['A4', 'LETTER', 'LEGAL']) ? $data['page_size'] : 'A4';
$state = $data['state'] ?? null;

if (!$templateId || !is_array($state) || empty($state['pages'])) {
    echo json_encode(['ok' => false, 'error' => 'Nothing to save yet — upload at least one image first.']);
    exit;
}

$stateJson = json_encode($state);
if ($stateJson === false) {
    echo json_encode(['ok' => false, 'error' => 'Could not encode paper state.']);
    exit;
}
// A safety cap — with images now stored as files (not embedded base64), the saved
// state is just positions/filters/URLs, so this should never realistically be hit.
if (strlen($stateJson) > 5 * 1024 * 1024) {
    echo json_encode(['ok' => false, 'error' => "This paper's saved data is unexpectedly large. Please contact support."]);
    exit;
}

try {
    $pageCount = count($state['pages']);

    if ($id) {
        // Make sure this paper belongs to the current user before updating it.
        $check = $pdo->prepare('SELECT id FROM papers WHERE id = ? AND user_id = ?');
        $check->execute([$id, $user['id']]);
        if (!$check->fetch()) {
            echo json_encode(['ok' => false, 'error' => 'Paper not found.']);
            exit;
        }
        $stmt = $pdo->prepare(
            'UPDATE papers SET template_id=?, title=?, page_size=?, page_count=?, canvas_json=? WHERE id=? AND user_id=?'
        );
        $stmt->execute([$templateId, $title, $pageSize, $pageCount, $stateJson, $id, $user['id']]);
    } else {
        $stmt = $pdo->prepare(
            'INSERT INTO papers (user_id, template_id, title, page_size, page_count, canvas_json, status)
             VALUES (?,?,?,?,?,?,"draft")'
        );
        $stmt->execute([$user['id'], $templateId, $title, $pageSize, $pageCount, $stateJson]);
        $id = (int) $pdo->lastInsertId();
    }
    log_activity($pdo, $user['id'], "Saved question paper '$title'");
    echo json_encode(['ok' => true, 'id' => $id]);
} catch (Exception $e) {
    echo json_encode(['ok' => false, 'error' => 'Server error: ' . $e->getMessage()]);
}
