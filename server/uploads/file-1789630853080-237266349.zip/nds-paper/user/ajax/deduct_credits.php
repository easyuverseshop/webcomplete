<?php
require_once __DIR__ . '/../../config/config.php';
header('Content-Type: application/json');

if (!is_logged_in() || is_admin()) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'Not authorized']);
    exit;
}

$raw = file_get_contents('php://input');
$data = json_decode($raw, true) ?? [];

if (!csrf_check($data['csrf'] ?? null)) {
    echo json_encode(['ok' => false, 'error' => 'Session expired. Please refresh the page and try again.']);
    exit;
}

$user = current_user();
$title = trim($data['title'] ?? 'Untitled Question Paper');
$templateId = (int) ($data['template_id'] ?? 0);
$pageCount = max(1, (int) ($data['page_count'] ?? 1));
$pageSize = in_array($data['page_size'] ?? 'A4', ['A4', 'LETTER', 'LEGAL']) ? $data['page_size'] : 'A4';

try {
    // Always fetch the true balance first — the client's on-screen number can be stale
    // (e.g. opened in another tab, or several minutes ago), so we never trust it for the check.
    $stmt = $pdo->prepare('SELECT credits FROM users WHERE id = ?');
    $stmt->execute([$user['id']]);
    $row = $stmt->fetch();
    if (!$row) {
        echo json_encode(['ok' => false, 'error' => 'Your account could not be found. Please log in again.']);
        exit;
    }
    $currentBalance = (int) $row['credits'];

    if ($currentBalance < COST_PER_DOWNLOAD) {
        echo json_encode([
            'ok' => false,
            'balance' => $currentBalance,
            'error' => "You have $currentBalance credits, but downloading needs " . COST_PER_DOWNLOAD . ". Please contact your administrator for more credits.",
        ]);
        exit;
    }

    $success = adjust_credits($pdo, $user['id'], -COST_PER_DOWNLOAD, "Downloaded paper: $title");
    if (!$success) {
        echo json_encode(['ok' => false, 'balance' => $currentBalance, 'error' => 'Could not process the credit deduction. Please try again.']);
        exit;
    }

    $stmt = $pdo->prepare(
        'INSERT INTO papers (user_id, template_id, title, page_size, page_count, credits_used, status)
         VALUES (?,?,?,?,?,?,"downloaded")'
    );
    $stmt->execute([$user['id'], $templateId, $title, $pageSize, $pageCount, COST_PER_DOWNLOAD]);
    log_activity($pdo, $user['id'], "Downloaded question paper '$title'");

    $stmt = $pdo->prepare('SELECT credits FROM users WHERE id = ?');
    $stmt->execute([$user['id']]);
    $balance = (int) $stmt->fetch()['credits'];

    // keep the session copy in sync
    $_SESSION['user']['credits'] = $balance;

    echo json_encode(['ok' => true, 'balance' => $balance]);
} catch (Exception $e) {
    echo json_encode(['ok' => false, 'error' => 'Server error: ' . $e->getMessage()]);
}
