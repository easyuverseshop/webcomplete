<?php
require_once __DIR__ . '/../../config/config.php';
header('Content-Type: application/json');

if (!is_logged_in() || is_admin()) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'Not authorized']);
    exit;
}

$user = current_user();
$id = (int) ($_GET['id'] ?? 0);

$stmt = $pdo->prepare('SELECT * FROM papers WHERE id = ? AND user_id = ?');
$stmt->execute([$id, $user['id']]);
$paper = $stmt->fetch();

if (!$paper) {
    echo json_encode(['ok' => false, 'error' => 'Paper not found.']);
    exit;
}

$state = json_decode($paper['canvas_json'] ?? 'null', true);
if (!$state) {
    echo json_encode(['ok' => false, 'error' => 'This paper has no saved editor state (it may only exist as a download record).']);
    exit;
}

unset($paper['canvas_json']); // sent separately as decoded `state`
echo json_encode(['ok' => true, 'paper' => $paper, 'state' => $state]);
