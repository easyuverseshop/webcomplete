<?php
require_once __DIR__ . '/../config/config.php';
require_login();
if (is_admin()) { header('Location: ../admin/dashboard.php'); exit; }
refresh_session_user($pdo);
$me = current_user();

$templates = templates_for_user($pdo, $me['id']);
if (!$templates) {
    header('Location: dashboard.php');
    exit;
}
$preselect = (int) ($_GET['template'] ?? $templates[0]['id']);
$paperId = (int) ($_GET['paper'] ?? 0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Create question paper — NDS Paper</title>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:wght@500;600;700&family=Inter:wght@400;500;600;700&family=IBM+Plex+Mono:wght@500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="assets/editor.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/fabric.js/5.3.0/fabric.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.15.0/Sortable.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
</head>
<body class="editor-body">

<header class="ed-topbar">
  <div class="tb-row tb-row-1">
    <div class="tb-left">
      <a href="dashboard.php" class="ed-back" title="Back to dashboard">&larr;</a>
      <input type="text" id="paperTitle" value="Untitled Question Paper" class="title-input">
    </div>
    <button class="tb-menu-toggle" id="btnToolbarMenu" aria-label="More options">&#8942;</button>
  </div>

  <div class="tb-row tb-row-2" id="tbRow2">
    <label class="tb-field">Template
      <select id="templateSelect">
        <?php foreach ($templates as $t): ?>
        <option value="<?= $t['id'] ?>" <?= $t['id']==$preselect?'selected':'' ?>><?= h($t['name']) ?></option>
        <?php endforeach; ?>
      </select>
    </label>
    <label class="tb-field">Paper size
      <select id="pageSizeSelect">
        <option value="A4" selected>A4</option>
        <option value="LETTER">Letter</option>
        <option value="LEGAL">Legal</option>
      </select>
    </label>
    <div class="tb-field credits-chip">Credits<b id="creditsChip"><?= (int)$me['credits'] ?></b></div>

    <div class="tb-actions">
      <button class="btn btn-ghost btn-sm" id="btnUpload">+ Upload images</button>
      <input type="file" id="fileInput" accept="image/*" multiple style="display:none;">
      <button class="btn btn-ghost btn-sm" id="btnSavePaper">Save</button>
      <button class="btn btn-ghost btn-sm" id="btnPreview">Preview PDF</button>
      <button class="btn btn-stamp btn-sm" id="btnDownload">Download (10 credits)</button>
    </div>
  </div>
</header>

<div class="ed-shell">
  <!-- Page rail: compact, collapsible -->
  <aside class="ed-pages" id="edPages">
    <div class="ed-pages-head">
      <span>Pages <span id="pageCount">0</span></span>
      <button class="rail-toggle" id="btnCollapseRail" title="Collapse page list">&laquo;</button>
    </div>
    <div id="pageList" class="page-list"></div>
    <p class="hint">Drag to reorder. Page 1 keeps the header; others print full-bleed.</p>
  </aside>
  <button class="rail-expand" id="btnExpandRail" title="Show pages" style="display:none;">&raquo;</button>

  <!-- Canvas stage -->
  <main class="ed-stage">
    <div class="stage-scroll" id="stageScroll">
      <div id="canvasScale" class="canvas-scale">
        <div id="canvasWrap" class="canvas-wrap">
          <canvas id="pageCanvas"></canvas>
        </div>
      </div>
      <div id="emptyState" class="empty-state">
        <p>Upload your question images to get started.</p>
        <button class="btn btn-stamp" id="btnUploadEmpty">+ Upload images</button>
      </div>
    </div>
  </main>
</div>

<!-- Floating contextual panel: only appears when something is selected -->
<div class="float-panel" id="floatPanel" style="display:none;">
  <div class="fp-tabs">
    <button class="ptab active" data-panel="adjust">Adjust</button>
    <button class="ptab" data-panel="layers">Layers</button>
    <button class="fp-close" id="fpClose" title="Deselect">&times;</button>
  </div>

  <div class="ptab-content" id="panel-adjust">
    <div class="ctrl-group">
      <h4>Position</h4>
      <div class="ctrl"><label>Rotate <span id="valRotate">0&deg;</span></label><input type="range" id="ctlRotate" min="0" max="360" value="0"></div>
      <div class="ctrl"><label>Tilt <span id="valTilt">0&deg;</span></label><input type="range" id="ctlTilt" min="-30" max="30" value="0"></div>
      <div class="ctrl-row">
        <button class="btn btn-ghost btn-xs" id="btnRotateLeft">&#8634; 90&deg;</button>
        <button class="btn btn-ghost btn-xs" id="btnRotateRight">&#8635; 90&deg;</button>
        <button class="btn btn-ghost btn-xs" id="btnFlip">Flip</button>
      </div>
    </div>
    <div class="ctrl-group">
      <h4>Color</h4>
      <div class="ctrl"><label>Brightness <span id="valBrightness">0</span></label><input type="range" id="ctlBrightness" min="-100" max="100" value="0"></div>
      <div class="ctrl"><label>Contrast <span id="valContrast">0</span></label><input type="range" id="ctlContrast" min="-100" max="100" value="0"></div>
      <div class="ctrl"><label>Saturation <span id="valSaturation">0</span></label><input type="range" id="ctlSaturation" min="-100" max="100" value="0"></div>
    </div>
    <div class="ctrl-group">
      <h4>Crop</h4>
      <p class="hint" style="margin:0 0 8px;">Tip: set rotation to 0&deg; before cropping.</p>
      <div class="ctrl-row">
        <button class="btn btn-ghost btn-xs" id="btnCropStart">Start crop</button>
        <button class="btn btn-stamp btn-xs" id="btnCropApply" style="display:none;">Apply</button>
        <button class="btn btn-ghost btn-xs" id="btnCropCancel" style="display:none;">Cancel</button>
      </div>
    </div>
    <div class="ctrl-row">
      <button class="btn btn-ghost btn-xs btn-block" id="btnResetAdjust">Reset</button>
      <button class="btn btn-xs btn-block btn-danger" id="btnDeleteSelected">Delete</button>
    </div>
  </div>

  <div class="ptab-content" id="panel-layers" style="display:none;">
    <ul id="layerList" class="layer-list"></ul>
    <div id="logoLayerControls" style="display:none;">
      <hr class="rule" style="margin:12px 0;">
      <h4 style="font-size:.75rem;">Logo appearance (this paper only)</h4>
      <div class="ctrl"><label>Opacity <span id="valLogoOpacity">100</span>%</label><input type="range" id="ctlLogoOpacity" min="0" max="100" value="100"></div>
      <div class="ctrl"><label>Brightness <span id="valLogoBrightness">0</span></label><input type="range" id="ctlLogoBrightness" min="-100" max="100" value="0"></div>
      <div class="ctrl"><label>Contrast <span id="valLogoContrast">0</span></label><input type="range" id="ctlLogoContrast" min="-100" max="100" value="0"></div>
      <p class="hint" style="margin:0;">Transparent areas in your logo's original PNG file are preserved automatically — this slider lets you additionally fade it like a watermark.</p>
    </div>
  </div>
</div>

<!-- Preview modal -->
<div class="modal-backdrop" id="previewModal">
  <div class="modal modal-lg">
    <div class="modal-head"><h2 style="font-size:1.1rem;margin:0;">Final preview</h2><button class="close-x" data-close>&times;</button></div>
    <div class="modal-body" id="previewBody"><p style="color:#6b7280;text-align:center;">Generating preview&hellip;</p></div>
    <div class="modal-foot">
      <button type="button" class="btn btn-ghost" data-close>Close</button>
      <button type="button" class="btn btn-stamp" id="btnDownloadFromPreview">Download (10 credits)</button>
    </div>
  </div>
</div>

<script>
  window.CSRF_TOKEN = "<?= csrf_token() ?>";
  window.USER_CREDITS = <?= (int) $me['credits'] ?>;
  window.PAPER_ID = <?= $paperId ?: 'null' ?>;
  window.TEMPLATES = <?= json_encode(array_map(function($t){
      return [
        'id' => (int)$t['id'],
        'name' => $t['name'],
        'institute_name' => $t['institute_name'],
        'address_line1' => $t['address_line1'],
        'address_line2' => $t['address_line2'],
        'phone' => $t['phone'],
        'logo_path' => $t['logo_path'] ? '../' . $t['logo_path'] : null,
        'header_height_mm' => (int) ($t['header_height_mm'] ?: 32),
        'header_layout' => $t['header_layout'] ? json_decode($t['header_layout']) : null,
      ];
  }, $templates)) ?>;
</script>
<script src="assets/editor.js"></script>
</body>
</html>
