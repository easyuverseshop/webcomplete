/* =========================================================
   NDS Paper — Question Paper Editor
   Fabric.js (canvas + image transforms/filters), SortableJS
   (page reordering) and jsPDF (final export).
   ========================================================= */

const PX_PER_MM = 96 / 25.4;
const PAGE_SIZES_MM = {
  A4:     { w: 210, h: 297 },
  LETTER: { w: 216, h: 279 },
  LEGAL:  { w: 216, h: 356 },
};
const FOOTER_HEIGHT_MM = 10;
const SIDE_MARGIN_MM = 6;
const DESIGN_WIDTH_PX = Math.round(210 * PX_PER_MM);

function headerHeightMm() { return currentTemplate.header_height_mm || 32; }
function defaultHeaderLayout() {
  const marginPx = SIDE_MARGIN_MM * PX_PER_MM;
  return {
    canvasWidth: DESIGN_WIDTH_PX,
    logo: { left: marginPx, top: 10, scaleX: null, scaleY: null },
    institute: { left: marginPx + 64, top: 12, fontSize: 22, fill: '#0F1B2D', textAlign: 'left', fontWeight: '700' },
    address: { left: marginPx + 64, top: 40, fontSize: 11, fill: '#5b636b', textAlign: 'left', fontWeight: '400' },
  };
}

let currentTemplate = window.TEMPLATES.find(t => t.id === Number(document.getElementById('templateSelect').value)) || window.TEMPLATES[0];
let pageSizeKey = 'A4';
let canvas = null;
let pages = [];           // [{ imgSrc, filters:{b,c,s}, angle, skewX, flipX, left, top, scaleX, scaleY, cropX, cropY, cropW, cropH, natW, natH }]
let currentIndex = -1;
let activeEditable = null;
let activeEditableKind = null;
let logoState = { filters: { b: 0, c: 0 }, left: null, top: null, scaleX: null, scaleY: null, opacity: 1 };
let cropRect = null;
let isCropping = false;
let currentPaperId = window.PAPER_ID || null;

function pageDimsPx() {
  const mm = PAGE_SIZES_MM[pageSizeKey];
  return { wPx: Math.round(mm.w * PX_PER_MM), hPx: Math.round(mm.h * PX_PER_MM), wMm: mm.w, hMm: mm.h };
}

/* ---------------------------------------------------------
   Canvas bootstrap + auto-fit scaling
   --------------------------------------------------------- */
function initCanvas() {
  const { wPx, hPx } = pageDimsPx();
  canvas = new fabric.Canvas('pageCanvas', { backgroundColor: '#ffffff', preserveObjectStacking: true });
  canvas.setWidth(wPx);
  canvas.setHeight(hPx);
  document.getElementById('canvasWrap').style.width = wPx + 'px';

  canvas.on('selection:created', onSelectionChange);
  canvas.on('selection:updated', onSelectionChange);
  canvas.on('selection:cleared', hideFloatPanel);
  canvas.on('object:modified', captureTransformFromCanvas);

  fitCanvasToStage();
  syncShellHeight();
  window.addEventListener('resize', debounce(fitCanvasToStage, 120));
}

function fitCanvasToStage() {
  const stage = document.getElementById('stageScroll');
  const { wPx, hPx } = pageDimsPx();
  const available = stage.clientWidth - 32;
  const scale = Math.min(1, available / wPx);
  document.getElementById('canvasScale').style.transform = `scale(${scale})`;
  document.getElementById('canvasScale').style.width = wPx + 'px';
  document.getElementById('canvasScale').style.marginBottom = (scale < 1 ? -(1 - scale) * hPx : 0) + 'px';
}
function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }

function syncShellHeight() {
  const topbar = document.querySelector('.ed-topbar');
  document.querySelector('.ed-shell').style.height = (window.innerHeight - topbar.offsetHeight) + 'px';
}
window.addEventListener('resize', debounce(syncShellHeight, 100));
document.getElementById('btnToolbarMenu').addEventListener('click', () => setTimeout(syncShellHeight, 10));

function showFloatPanel() { document.getElementById('floatPanel').style.display = 'block'; }
function hideFloatPanel() {
  if (isCropping) return;
  activeEditable = null; activeEditableKind = null;
  document.getElementById('floatPanel').style.display = 'none';
}

function onSelectionChange(e) {
  if (isCropping) return; // keep the panel exactly as-is while the crop rectangle is selected
  const obj = e.selected ? e.selected[0] : canvas.getActiveObject();
  if (!obj || !obj.editableKind) { hideFloatPanel(); return; }
  activeEditable = obj;
  activeEditableKind = obj.editableKind;
  syncAdjustPanelFromObject(obj);
  showFloatPanel();
  highlightLayerListSelection();
}

document.getElementById('fpClose').addEventListener('click', () => { canvas.discardActiveObject(); canvas.requestRenderAll(); hideFloatPanel(); });

/* ---------------------------------------------------------
   Building a page from stored state (or fresh defaults)
   --------------------------------------------------------- */
function buildPage(index) {
  return new Promise(resolve => {
    const { wPx, hPx } = pageDimsPx();
    canvas.clear();
    canvas.backgroundColor = '#ffffff';
    const isFirst = index === 0;
    const footerPx = FOOTER_HEIGHT_MM * PX_PER_MM;
    const marginPx = SIDE_MARGIN_MM * PX_PER_MM;
    const p = pages[index];
    let pendingLogo = Promise.resolve();
    const headerPx = headerHeightMm() * PX_PER_MM;

    if (isFirst) {
      const layout = currentTemplate.header_layout || defaultHeaderLayout();
      const scale = wPx / (layout.canvasWidth || DESIGN_WIDTH_PX);

      canvas.add(new fabric.Line([marginPx, headerPx - 6, wPx - marginPx, headerPx - 6], {
        stroke: '#0F1B2D', strokeWidth: 2, selectable: false, evented: false,
      }));
      canvas.add(new fabric.Textbox(currentTemplate.institute_name || '', {
        left: layout.institute.left * scale, top: layout.institute.top * scale,
        fontSize: layout.institute.fontSize * scale, fontWeight: layout.institute.fontWeight || '700',
        fontStyle: layout.institute.fontStyle || 'normal',
        fontFamily: layout.institute.fontFamily || 'Georgia, serif', fill: layout.institute.fill || '#0F1B2D',
        textAlign: layout.institute.textAlign || 'left', selectable: false, evented: false,
        width: wPx - layout.institute.left * scale - marginPx,
      }));
      const addrLines = [currentTemplate.address_line1, currentTemplate.address_line2, currentTemplate.phone].filter(Boolean).join('   |   ');
      canvas.add(new fabric.Textbox(addrLines, {
        left: layout.address.left * scale, top: layout.address.top * scale,
        fontSize: layout.address.fontSize * scale, fontFamily: layout.address.fontFamily || 'Arial',
        fontStyle: layout.address.fontStyle || 'normal', fill: layout.address.fill || '#5b636b',
        textAlign: layout.address.textAlign || 'left', selectable: false, evented: false,
        width: wPx - layout.address.left * scale - marginPx,
      }));
      if (currentTemplate.logo_path) {
        pendingLogo = new Promise(res => {
          fabric.Image.fromURL(currentTemplate.logo_path, img => {
            const targetH = headerPx - 20;
            const designScale = layout.logo && layout.logo.scaleX ? layout.logo.scaleX * scale : targetH / img.height;
            img.set({
              left: logoState.left ?? (layout.logo ? layout.logo.left * scale : marginPx),
              top: logoState.top ?? (layout.logo ? layout.logo.top * scale : 10),
              scaleX: logoState.scaleX ?? designScale,
              scaleY: logoState.scaleY ?? designScale,
              opacity: logoState.opacity ?? 1,
              editableKind: 'logo', hasRotatingPoint: true,
            });
            img.filters = buildFilterArray(logoState.filters);
            img.applyFilters();
            canvas.add(img);
            window.__logoObj = img;
            res();
          }, { crossOrigin: 'anonymous' });
        });
      }
    }

    const areaTop = isFirst ? headerPx : 0;
    const areaHeight = hPx - areaTop - footerPx;
    const areaWidth = wPx - marginPx * 2;

    pendingLogo.then(() => {
      window.__mainImg = null;
      if (p && p.imgSrc) {
        fabric.Image.fromURL(p.imgSrc, img => {
          if (p.natW == null) { p.natW = img.width; p.natH = img.height; }
          if (p.left == null) {
            const scale = Math.min(areaWidth / img.width, areaHeight / img.height);
            p.scaleX = scale; p.scaleY = scale;
            p.left = marginPx + (areaWidth - img.width * scale) / 2;
            p.top = areaTop + (areaHeight - img.height * scale) / 2;
            p.angle = 0; p.skewX = 0; p.flipX = false;
            p.filters = { b: 0, c: 0, s: 0 };
          }
          img.set({
            left: p.left, top: p.top, scaleX: p.scaleX, scaleY: p.scaleY,
            angle: p.angle, skewX: p.skewX, flipX: p.flipX,
            editableKind: 'main', cropX: p.cropX || 0, cropY: p.cropY || 0,
          });
          if (p.cropW) img.width = p.cropW;
          if (p.cropH) img.height = p.cropH;
          img.filters = buildFilterArray(p.filters);
          img.applyFilters();
          canvas.add(img);
          window.__mainImg = img;
          addFooter(index, wPx, hPx, footerPx, marginPx);
          canvas.requestRenderAll();
          resolve();
        }, { crossOrigin: 'anonymous' });
      } else {
        addFooter(index, wPx, hPx, footerPx, marginPx);
        canvas.requestRenderAll();
        resolve();
      }
    });
  });
}

function addFooter(index, wPx, hPx, footerPx, marginPx) {
  const barTop = hPx - footerPx;
  canvas.add(new fabric.Rect({ left: 0, top: barTop, width: wPx, height: footerPx, fill: 'rgba(255,255,255,0.82)', selectable: false, evented: false }));
  canvas.add(new fabric.Line([marginPx, barTop + 2, wPx - marginPx, barTop + 2], { stroke: '#D8D2C4', strokeWidth: 1, selectable: false, evented: false }));
  canvas.add(new fabric.Textbox(currentTemplate.institute_name || '', {
    left: marginPx, top: barTop + footerPx / 2 - 8, fontSize: 10, fill: '#5b636b', fontFamily: 'Arial',
    selectable: false, evented: false, width: wPx * 0.6,
  }));
  canvas.add(new fabric.Textbox(`Page ${index + 1} of ${pages.length}`, {
    left: wPx - marginPx - 140, top: barTop + footerPx / 2 - 8, fontSize: 10, fill: '#5b636b', fontFamily: 'Arial',
    width: 140, textAlign: 'right', selectable: false, evented: false,
  }));
}

function buildFilterArray(f) {
  if (!f) return [];
  return [
    new fabric.Image.filters.Brightness({ brightness: (f.b || 0) / 100 }),
    new fabric.Image.filters.Contrast({ contrast: (f.c || 0) / 100 }),
    new fabric.Image.filters.Saturation({ saturation: (f.s || 0) / 100 }),
  ];
}

function captureTransformFromCanvas(e) {
  const obj = e.target;
  if (!obj || !obj.editableKind) return;
  if (obj.editableKind === 'main' && pages[currentIndex]) {
    Object.assign(pages[currentIndex], { left: obj.left, top: obj.top, scaleX: obj.scaleX, scaleY: obj.scaleY, angle: obj.angle, skewX: obj.skewX, flipX: obj.flipX });
  } else if (obj.editableKind === 'logo') {
    Object.assign(logoState, { left: obj.left, top: obj.top, scaleX: obj.scaleX, scaleY: obj.scaleY });
  }
}

/* ---------------------------------------------------------
   Page navigation
   --------------------------------------------------------- */
async function goToPage(index) {
  if (currentIndex >= 0 && canvas.getActiveObject()) captureTransformFromCanvas({ target: canvas.getActiveObject() });
  currentIndex = index;
  await buildPage(index);
  renderPageList();
  hideFloatPanel();
  renderLayerList();
  fitCanvasToStage();
}

function renderPageList() {
  const list = document.getElementById('pageList');
  list.innerHTML = '';
  document.getElementById('pageCount').textContent = pages.length;
  pages.forEach((p, i) => {
    const div = document.createElement('div');
    div.className = 'page-thumb' + (i === currentIndex ? ' active' : '');
    div.dataset.index = i;
    div.innerHTML = `<img src="${p.imgSrc || ''}" alt=""><div class="p-label">Pg ${i + 1}${i === 0 ? ' &#9733;' : ''}</div><button class="p-remove" title="Remove page">&times;</button>`;
    div.querySelector('img').addEventListener('click', () => goToPage(i));
    div.querySelector('.p-remove').addEventListener('click', (ev) => { ev.stopPropagation(); removePage(i); });
    list.appendChild(div);
  });
  if (window.__sortable) window.__sortable.destroy();
  window.__sortable = new Sortable(list, {
    animation: 150,
    onEnd: (evt) => {
      const moved = pages.splice(evt.oldIndex, 1)[0];
      pages.splice(evt.newIndex, 0, moved);
      if (currentIndex === evt.oldIndex) currentIndex = evt.newIndex;
      goToPage(currentIndex);
    },
  });
}

function removePage(i) {
  if (pages.length <= 1) { alert('A question paper needs at least one page.'); return; }
  pages.splice(i, 1);
  if (currentIndex >= pages.length) currentIndex = pages.length - 1;
  goToPage(currentIndex);
}

/* ---------------------------------------------------------
   Upload
   --------------------------------------------------------- */
document.getElementById('btnUpload').addEventListener('click', () => document.getElementById('fileInput').click());
document.getElementById('btnUploadEmpty').addEventListener('click', () => document.getElementById('fileInput').click());
document.getElementById('fileInput').addEventListener('change', async (e) => {
  const files = Array.from(e.target.files || []);
  if (!files.length) return;
  document.getElementById('emptyState').innerHTML = '<p>Uploading&hellip;</p>';
  document.getElementById('emptyState').style.display = 'flex';

  for (const file of files) {
    const url = await uploadImageToServer(file);
    if (url) {
      pages.push({ imgSrc: url, filters: { b: 0, c: 0, s: 0 }, angle: 0, skewX: 0, flipX: false, left: null, top: null });
    }
  }
  e.target.value = '';
  document.getElementById('emptyState').innerHTML = '<p>Upload your question images to get started.</p><button class="btn btn-stamp" id="btnUploadEmpty2">+ Upload images</button>';
  document.getElementById('emptyState').style.display = pages.length ? 'none' : 'flex';
  const btn2 = document.getElementById('btnUploadEmpty2');
  if (btn2) btn2.addEventListener('click', () => document.getElementById('fileInput').click());
  if (currentIndex === -1 && pages.length) currentIndex = 0;
  if (pages.length) await goToPage(currentIndex);
});
async function uploadImageToServer(file) {
  const fd = new FormData();
  fd.append('image', file);
  fd.append('csrf', window.CSRF_TOKEN);
  try {
    const res = await fetch('ajax/upload_image.php', { method: 'POST', body: fd });
    const data = await res.json();
    if (!data.ok) { alert(`Could not upload "${file.name}": ` + (data.error || 'unknown error')); return null; }
    return '../' + data.url;
  } catch (err) {
    alert(`Could not upload "${file.name}" — check your connection and try again.`);
    return null;
  }
}

/* ---------------------------------------------------------
   Template / page size switching
   --------------------------------------------------------- */
document.getElementById('templateSelect').addEventListener('change', async (e) => {
  currentTemplate = window.TEMPLATES.find(t => t.id === Number(e.target.value));
  logoState = { filters: { b: 0, c: 0 }, left: null, top: null, scaleX: null, scaleY: null, opacity: 1 };
  if (currentIndex >= 0) await goToPage(currentIndex);
});
document.getElementById('pageSizeSelect').addEventListener('change', async (e) => {
  pageSizeKey = e.target.value;
  const { wPx, hPx } = pageDimsPx();
  canvas.setWidth(wPx); canvas.setHeight(hPx);
  document.getElementById('canvasWrap').style.width = wPx + 'px';
  pages.forEach(p => { p.left = null; p.top = null; });
  if (currentIndex >= 0) await goToPage(currentIndex);
  fitCanvasToStage();
});

/* ---------------------------------------------------------
   Adjust panel <-> object binding
   --------------------------------------------------------- */
function syncAdjustPanelFromObject(obj) {
  const f = obj.editableKind === 'logo' ? logoState.filters : pages[currentIndex].filters;
  setSlider('ctlBrightness', 'valBrightness', (f.b || 0), '');
  setSlider('ctlContrast', 'valContrast', (f.c || 0), '');
  setSlider('ctlSaturation', 'valSaturation', (f.s || 0), '');
  setSlider('ctlRotate', 'valRotate', Math.round(obj.angle || 0), '&deg;');
  setSlider('ctlTilt', 'valTilt', Math.round(obj.skewX || 0), '&deg;');
}
function setSlider(inputId, labelId, val, suffix) {
  document.getElementById(inputId).value = val;
  document.getElementById(labelId).innerHTML = val + suffix;
}
function applyFilterUpdate() {
  if (!activeEditable) return;
  const store = activeEditableKind === 'logo' ? logoState.filters : pages[currentIndex].filters;
  store.b = Number(document.getElementById('ctlBrightness').value);
  store.c = Number(document.getElementById('ctlContrast').value);
  store.s = Number(document.getElementById('ctlSaturation').value);
  activeEditable.filters = buildFilterArray(store);
  activeEditable.applyFilters();
  canvas.requestRenderAll();
}
['ctlBrightness', 'ctlContrast', 'ctlSaturation'].forEach(id => {
  document.getElementById(id).addEventListener('input', (e) => {
    document.getElementById('val' + id.replace('ctl', '')).textContent = e.target.value;
    applyFilterUpdate();
  });
});
document.getElementById('ctlRotate').addEventListener('input', (e) => {
  document.getElementById('valRotate').innerHTML = e.target.value + '&deg;';
  if (activeEditable) { activeEditable.set({ angle: Number(e.target.value) }); canvas.requestRenderAll(); captureTransformFromCanvas({ target: activeEditable }); }
});
document.getElementById('ctlTilt').addEventListener('input', (e) => {
  document.getElementById('valTilt').innerHTML = e.target.value + '&deg;';
  if (activeEditable) { activeEditable.set({ skewX: Number(e.target.value) }); canvas.requestRenderAll(); captureTransformFromCanvas({ target: activeEditable }); }
});
document.getElementById('btnRotateLeft').addEventListener('click', () => rotateBy(-90));
document.getElementById('btnRotateRight').addEventListener('click', () => rotateBy(90));
function rotateBy(delta) {
  if (!activeEditable) return;
  const newAngle = ((activeEditable.angle || 0) + delta + 360) % 360;
  activeEditable.set({ angle: newAngle });
  canvas.requestRenderAll();
  captureTransformFromCanvas({ target: activeEditable });
  setSlider('ctlRotate', 'valRotate', newAngle, '&deg;');
}
document.getElementById('btnFlip').addEventListener('click', () => {
  if (!activeEditable) return;
  activeEditable.set({ flipX: !activeEditable.flipX });
  canvas.requestRenderAll();
  captureTransformFromCanvas({ target: activeEditable });
});
document.getElementById('btnResetAdjust').addEventListener('click', () => {
  if (!activeEditable) return;
  if (activeEditableKind === 'main') {
    Object.assign(pages[currentIndex], { left: null, top: null, angle: 0, skewX: 0, flipX: false, filters: { b: 0, c: 0, s: 0 }, cropX: 0, cropY: 0, cropW: null, cropH: null });
  } else {
    logoState = { filters: { b: 0, c: 0 }, left: null, top: null, scaleX: null, scaleY: null, opacity: 1 };
  }
  goToPage(currentIndex);
});
document.getElementById('btnDeleteSelected').addEventListener('click', () => {
  if (!activeEditable) return;
  if (activeEditableKind === 'main') {
    if (!confirm('Remove this page? The uploaded image on it will be deleted.')) return;
    removePage(currentIndex);
  } else {
    alert("The logo is managed by your administrator and can't be deleted here — you can only adjust its brightness/contrast or reposition it for this paper.");
  }
});

/* ---------------------------------------------------------
   Crop
   --------------------------------------------------------- */
document.getElementById('btnCropStart').addEventListener('click', () => {
  if (!activeEditable) return;
  isCropping = true;
  const obj = activeEditable;
  cropRect = new fabric.Rect({
    left: obj.left, top: obj.top, width: obj.width * obj.scaleX, height: obj.height * obj.scaleY,
    fill: 'rgba(178,58,46,0.15)', stroke: '#B23A2E', strokeDashArray: [6, 4], strokeWidth: 2,
  });
  canvas.add(cropRect);
  canvas.setActiveObject(cropRect);
  canvas.requestRenderAll();
  document.getElementById('btnCropStart').style.display = 'none';
  document.getElementById('btnCropApply').style.display = 'inline-flex';
  document.getElementById('btnCropCancel').style.display = 'inline-flex';
});
document.getElementById('btnCropApply').addEventListener('click', () => {
  if (!cropRect || !activeEditable || activeEditableKind !== 'main') return endCrop();
  const obj = activeEditable;
  const p = pages[currentIndex];
  const relX = (cropRect.left - obj.left) / obj.scaleX + (p.cropX || 0);
  const relY = (cropRect.top - obj.top) / obj.scaleY + (p.cropY || 0);
  const relW = (cropRect.width * cropRect.scaleX) / obj.scaleX;
  const relH = (cropRect.height * cropRect.scaleY) / obj.scaleY;
  p.cropX = Math.max(0, relX); p.cropY = Math.max(0, relY);
  p.cropW = Math.max(10, relW); p.cropH = Math.max(10, relH);
  p.left = cropRect.left; p.top = cropRect.top;
  endCrop();
  goToPage(currentIndex);
});
document.getElementById('btnCropCancel').addEventListener('click', endCrop);
function endCrop() {
  isCropping = false;
  if (cropRect) { canvas.remove(cropRect); cropRect = null; }
  document.getElementById('btnCropStart').style.display = 'inline-flex';
  document.getElementById('btnCropApply').style.display = 'none';
  document.getElementById('btnCropCancel').style.display = 'none';
  canvas.requestRenderAll();
}

/* ---------------------------------------------------------
   Floating panel tabs + Layers list
   --------------------------------------------------------- */
document.querySelectorAll('.fp-tabs .ptab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.fp-tabs .ptab').forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    document.querySelectorAll('.ptab-content').forEach(c => c.style.display = 'none');
    document.getElementById('panel-' + tab.dataset.panel).style.display = 'block';
    if (tab.dataset.panel === 'layers') renderLayerList();
  });
});

function renderLayerList() {
  const ul = document.getElementById('layerList');
  ul.innerHTML = '';
  const items = [];
  if (currentIndex === 0 && window.__logoObj) items.push({ kind: 'logo', label: 'Institute logo' });
  if (window.__mainImg) items.push({ kind: 'main', label: 'Question image' });
  items.forEach(it => {
    const li = document.createElement('li');
    li.dataset.kind = it.kind;
    li.innerHTML = `<span>${it.label}</span><span><button data-act="front">Front</button> <button data-act="back">Back</button></span>`;
    li.querySelector('span').addEventListener('click', () => selectByKind(it.kind));
    li.querySelectorAll('button').forEach(btn => btn.addEventListener('click', (ev) => {
      ev.stopPropagation();
      const obj = it.kind === 'logo' ? window.__logoObj : window.__mainImg;
      if (btn.dataset.act === 'front') canvas.bringToFront(obj); else canvas.sendToBack(obj);
      canvas.requestRenderAll();
    }));
    ul.appendChild(li);
  });
  document.getElementById('logoLayerControls').style.display = (currentIndex === 0 && window.__logoObj) ? 'block' : 'none';
  if (currentIndex === 0 && window.__logoObj) {
    document.getElementById('ctlLogoOpacity').value = Math.round((logoState.opacity ?? 1) * 100);
    document.getElementById('valLogoOpacity').textContent = Math.round((logoState.opacity ?? 1) * 100);
    document.getElementById('ctlLogoBrightness').value = logoState.filters.b;
    document.getElementById('valLogoBrightness').textContent = logoState.filters.b;
    document.getElementById('ctlLogoContrast').value = logoState.filters.c;
    document.getElementById('valLogoContrast').textContent = logoState.filters.c;
  }
  highlightLayerListSelection();
}
function selectByKind(kind) {
  const obj = kind === 'logo' ? window.__logoObj : window.__mainImg;
  if (!obj) return;
  canvas.setActiveObject(obj);
  canvas.requestRenderAll();
}
function highlightLayerListSelection() {
  document.querySelectorAll('#layerList li').forEach(li => li.classList.toggle('selected', li.dataset.kind === activeEditableKind));
}
document.getElementById('ctlLogoOpacity').addEventListener('input', () => {
  const val = Number(document.getElementById('ctlLogoOpacity').value);
  document.getElementById('valLogoOpacity').textContent = val;
  logoState.opacity = val / 100;
  if (window.__logoObj) {
    window.__logoObj.set({ opacity: logoState.opacity });
    canvas.requestRenderAll();
  }
});
['ctlLogoBrightness', 'ctlLogoContrast'].forEach(id => {
  document.getElementById(id).addEventListener('input', () => {
    document.getElementById('val' + id.replace('ctl', '')).textContent = document.getElementById(id).value;
    logoState.filters.b = Number(document.getElementById('ctlLogoBrightness').value);
    logoState.filters.c = Number(document.getElementById('ctlLogoContrast').value);
    if (window.__logoObj) {
      window.__logoObj.filters = buildFilterArray(logoState.filters);
      window.__logoObj.applyFilters();
      canvas.requestRenderAll();
    }
  });
});

/* ---------------------------------------------------------
   Page rail collapse / expand
   --------------------------------------------------------- */
document.getElementById('btnCollapseRail').addEventListener('click', () => {
  document.getElementById('edPages').classList.add('collapsed');
  document.getElementById('btnExpandRail').style.display = 'block';
  setTimeout(fitCanvasToStage, 160);
});
document.getElementById('btnExpandRail').addEventListener('click', () => {
  document.getElementById('edPages').classList.remove('collapsed');
  document.getElementById('btnExpandRail').style.display = 'none';
  setTimeout(fitCanvasToStage, 160);
});

/* Mobile topbar row 2 toggle */
document.getElementById('btnToolbarMenu').addEventListener('click', () => {
  document.getElementById('tbRow2').classList.toggle('open');
});

/* ---------------------------------------------------------
   PDF generation (preview + download)
   --------------------------------------------------------- */
async function renderAllPagesToDataURLs() {
  if (canvas.getActiveObject()) { captureTransformFromCanvas({ target: canvas.getActiveObject() }); canvas.discardActiveObject(); }
  const urls = [];
  const savedIndex = currentIndex;
  for (let i = 0; i < pages.length; i++) {
    await buildPage(i);
    canvas.discardActiveObject();
    canvas.requestRenderAll();
    urls.push(canvas.toDataURL({ format: 'jpeg', quality: 0.92, multiplier: 2 }));
  }
  await goToPage(savedIndex);
  return urls;
}
function buildPdfDoc(dataURLs) {
  const { wMm, hMm } = pageDimsPx();
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF({ unit: 'mm', format: [wMm, hMm] });
  dataURLs.forEach((durl, i) => {
    if (i > 0) doc.addPage([wMm, hMm]);
    doc.addImage(durl, 'JPEG', 0, 0, wMm, hMm);
  });
  return doc;
}
document.getElementById('btnPreview').addEventListener('click', async () => {
  if (!pages.length) return alert('Upload at least one image before previewing.');
  document.getElementById('previewModal').classList.add('open');
  document.getElementById('previewBody').innerHTML = '<p style="color:#6b7280;text-align:center;">Generating preview&hellip;</p>';
  const urls = await renderAllPagesToDataURLs();
  // Rendered as plain images (not an embedded PDF) so the browser's native
  // PDF viewer never exposes its own save/print controls here — the only
  // way to get the actual file is the paid Download button below.
  document.getElementById('previewBody').innerHTML = urls.map((durl, i) => `
    <div class="preview-page">
      <div class="preview-watermark">PREVIEW &middot; not the final file</div>
      <img src="${durl}" alt="Page ${i + 1}" draggable="false" oncontextmenu="return false;">
      <div class="preview-page-label">Page ${i + 1} of ${urls.length}</div>
    </div>
  `).join('');
});
async function doDownload() {
  if (!pages.length) return alert('Upload at least one image before downloading.');
  if (!confirm('Downloading will deduct 10 credits from your balance. Continue?')) return;

  const downloadBtns = [document.getElementById('btnDownload'), document.getElementById('btnDownloadFromPreview')];
  downloadBtns.forEach(b => { b.disabled = true; b.dataset.origText = b.textContent; b.textContent = 'Processing…'; });

  try {
    const title = document.getElementById('paperTitle').value || 'Untitled Question Paper';
    const res = await fetch('ajax/deduct_credits.php', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ csrf: window.CSRF_TOKEN, title, template_id: currentTemplate.id, page_count: pages.length, page_size: pageSizeKey }),
    });
    const data = await res.json();
    if (typeof data.balance === 'number') {
      window.USER_CREDITS = data.balance;
      document.getElementById('creditsChip').textContent = data.balance;
    }
    if (!data.ok) { alert(data.error || 'Could not process credits.'); return; }

    const urls = await renderAllPagesToDataURLs();
    const doc = buildPdfDoc(urls);
    doc.save(title.replace(/[^a-z0-9\- ]/gi, '') + '.pdf');
  } finally {
    downloadBtns.forEach(b => { b.disabled = false; b.textContent = b.dataset.origText; });
  }
}
document.getElementById('btnDownload').addEventListener('click', doDownload);
document.getElementById('btnDownloadFromPreview').addEventListener('click', doDownload);

document.querySelectorAll('[data-close]').forEach(btn => btn.addEventListener('click', () => btn.closest('.modal-backdrop').classList.remove('open')));
document.querySelectorAll('.modal-backdrop').forEach(bd => bd.addEventListener('click', e => { if (e.target === bd) bd.classList.remove('open'); }));

/* ---------------------------------------------------------
   Save / resume a paper (positions, filters, crop — the
   images themselves are stored too, so nothing needs
   re-uploading when you come back).
   --------------------------------------------------------- */
document.getElementById('btnSavePaper').addEventListener('click', savePaper);
async function savePaper() {
  if (!pages.length) return alert('Upload at least one image before saving.');
  if (canvas.getActiveObject()) captureTransformFromCanvas({ target: canvas.getActiveObject() });

  const btn = document.getElementById('btnSavePaper');
  btn.disabled = true; btn.textContent = 'Saving…';

  const payload = {
    csrf: window.CSRF_TOKEN,
    id: currentPaperId,
    title: document.getElementById('paperTitle').value || 'Untitled Question Paper',
    template_id: currentTemplate.id,
    page_size: pageSizeKey,
    state: { pages, logoState },
  };
  try {
    const res = await fetch('ajax/save_paper.php', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (data.ok) {
      currentPaperId = data.id;
      history.replaceState(null, '', 'editor.php?paper=' + data.id);
      btn.textContent = 'Saved \u2713';
    } else {
      alert(data.error || 'Could not save.');
      btn.textContent = 'Save';
    }
  } catch (err) {
    alert('Could not reach the server to save.');
    btn.textContent = 'Save';
  }
  setTimeout(() => { btn.disabled = false; if (btn.textContent !== 'Save') btn.textContent = 'Save'; }, 1600);
}

async function loadSavedPaper(id) {
  const res = await fetch('ajax/get_paper.php?id=' + id);
  const data = await res.json();
  if (!data.ok) { alert(data.error || 'Could not load the saved paper.'); return; }
  document.getElementById('paperTitle').value = data.paper.title;
  pageSizeKey = data.paper.page_size;
  document.getElementById('pageSizeSelect').value = pageSizeKey;
  document.getElementById('templateSelect').value = data.paper.template_id;
  currentTemplate = window.TEMPLATES.find(t => t.id === Number(data.paper.template_id)) || currentTemplate;
  pages = data.state.pages || [];
  logoState = data.state.logoState || logoState;
  const { wPx, hPx } = pageDimsPx();
  canvas.setWidth(wPx); canvas.setHeight(hPx);
  document.getElementById('canvasWrap').style.width = wPx + 'px';
  document.getElementById('emptyState').style.display = pages.length ? 'none' : 'flex';
  currentIndex = 0;
  await goToPage(0);
}

/* ---------------------------------------------------------
   Boot
   --------------------------------------------------------- */
initCanvas();
if (currentPaperId) loadSavedPaper(currentPaperId);
