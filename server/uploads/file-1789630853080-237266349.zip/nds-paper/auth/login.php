<?php
require_once __DIR__ . '/../config/config.php';
if (is_logged_in()) {
    header('Location: ' . (is_admin() ? '../admin/dashboard.php' : '../user/dashboard.php'));
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf'] ?? null)) {
        $error = 'Session expired. Please try again.';
    } else {
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ?');
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($password, $user['password_hash'])) {
            $error = 'Incorrect email or password.';
        } elseif ($user['status'] === 'blocked') {
            $error = 'This account has been blocked. Please contact your administrator.';
        } else {
            unset($user['password_hash']);
            $_SESSION['user'] = $user;
            log_activity($pdo, $user['id'], 'Logged in');
            header('Location: ' . ($user['role'] === 'admin' ? '../admin/dashboard.php' : '../user/dashboard.php'));
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Log in — NDS Paper</title>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:wght@500;600;700&family=Inter:wght@400;500;600;700&family=IBM+Plex+Mono:wght@500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="auth-shell">
  <div class="auth-side">
    <div class="brand"><div class="mark">NDS <span>Paper</span></div></div>
    <div class="quote">"Every question paper leaves looking like it came straight from the institute's own print desk."</div>
    <small style="font-family:var(--font-mono);opacity:.7;">Institute Print Studio</small>
  </div>
  <div class="auth-form-wrap">
    <div class="auth-card">
      <h2>Welcome back</h2>
      <p style="color:#6b7280;margin-bottom:24px;">Log in to your institute or admin dashboard.</p>
      <?php if ($error): ?><div class="alert alert-error"><?= h($error) ?></div><?php endif; ?>
      <?php if (isset($_GET['registered'])): ?><div class="alert alert-success">Account created — you can log in now.</div><?php endif; ?>
      <form method="post" novalidate>
        <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
        <div class="field">
          <label for="email">Email address</label>
          <input type="email" id="email" name="email" required autofocus value="<?= h($_POST['email'] ?? '') ?>">
        </div>
        <div class="field">
          <label for="password">Password</label>
          <input type="password" id="password" name="password" required>
        </div>
        <button type="submit" class="btn btn-stamp btn-block">Log in</button>
      </form>
      <div class="switch-link">New institute? <a href="register.php" style="color:var(--stamp);font-weight:600;">Register here</a></div>
    </div>
  </div>
</div>
</body>
</html>
