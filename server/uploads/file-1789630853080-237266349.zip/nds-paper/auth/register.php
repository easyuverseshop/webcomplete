<?php
require_once __DIR__ . '/../config/config.php';
if (is_logged_in()) {
    header('Location: ' . (is_admin() ? '../admin/dashboard.php' : '../user/dashboard.php'));
    exit;
}

$error = '';
$old = ['name'=>'','email'=>'','phone'=>'','institute_name'=>''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old = [
        'name' => trim($_POST['name'] ?? ''),
        'email' => trim($_POST['email'] ?? ''),
        'phone' => trim($_POST['phone'] ?? ''),
        'institute_name' => trim($_POST['institute_name'] ?? ''),
    ];
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm'] ?? '';

    if (!csrf_check($_POST['csrf'] ?? null)) {
        $error = 'Session expired. Please try again.';
    } elseif ($old['name'] === '' || $old['email'] === '' || $old['institute_name'] === '') {
        $error = 'Please fill in your name, institute name and email.';
    } elseif (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ?');
        $stmt->execute([$old['email']]);
        if ($stmt->fetch()) {
            $error = 'An account with this email already exists.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare(
                'INSERT INTO users (name, email, phone, password_hash, role, institute_name, credits) VALUES (?,?,?,?,"user",?,50)'
            );
            $stmt->execute([$old['name'], $old['email'], $old['phone'], $hash, $old['institute_name']]);
            $newId = (int) $pdo->lastInsertId();
            adjust_credits($pdo, $newId, 50, 'Welcome bonus on registration');
            log_activity($pdo, $newId, 'Registered new account');
            header('Location: login.php?registered=1');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Register your institute — NDS Paper</title>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:wght@500;600;700&family=Inter:wght@400;500;600;700&family=IBM+Plex+Mono:wght@500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="auth-shell">
  <div class="auth-side">
    <div class="brand"><div class="mark">NDS <span>Paper</span></div></div>
    <div class="quote">"Set up your institute once — every teacher after you prints on-brand from day one."</div>
    <small style="font-family:var(--font-mono);opacity:.7;">50 free credits on sign-up</small>
  </div>
  <div class="auth-form-wrap">
    <div class="auth-card">
      <h2>Create your account</h2>
      <p style="color:#6b7280;margin-bottom:24px;">Register your institute to start building question papers.</p>
      <?php if ($error): ?><div class="alert alert-error"><?= h($error) ?></div><?php endif; ?>
      <form method="post" novalidate>
        <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
        <div class="field">
          <label for="institute_name">Institute name</label>
          <input type="text" id="institute_name" name="institute_name" required value="<?= h($old['institute_name']) ?>" placeholder="Greenfield Public School">
        </div>
        <div class="field">
          <label for="name">Your name</label>
          <input type="text" id="name" name="name" required value="<?= h($old['name']) ?>">
        </div>
        <div class="field">
          <label for="email">Email address</label>
          <input type="email" id="email" name="email" required value="<?= h($old['email']) ?>">
        </div>
        <div class="field">
          <label for="phone">Mobile number</label>
          <input type="text" id="phone" name="phone" value="<?= h($old['phone']) ?>">
        </div>
        <div class="field">
          <label for="password">Password</label>
          <input type="password" id="password" name="password" required minlength="6">
        </div>
        <div class="field">
          <label for="confirm">Confirm password</label>
          <input type="password" id="confirm" name="confirm" required minlength="6">
        </div>
        <button type="submit" class="btn btn-stamp btn-block">Register institute</button>
      </form>
      <div class="switch-link">Already registered? <a href="login.php" style="color:var(--stamp);font-weight:600;">Log in</a></div>
    </div>
  </div>
</div>
</body>
</html>
