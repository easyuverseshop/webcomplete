<?php
require_once __DIR__ . '/../config/config.php';
if (is_logged_in()) {
    log_activity($pdo, $_SESSION['user']['id'], 'Logged out');
}
$_SESSION = [];
session_destroy();
header('Location: ../index.php');
exit;
