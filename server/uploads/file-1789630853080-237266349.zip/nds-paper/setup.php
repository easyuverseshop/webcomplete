<?php
/**
 * Run this ONCE after importing database/schema.sql, then delete this file.
 * It sets a proper bcrypt hash for the seeded admin account.
 * Default login after running: admin@ndspaper.com / Admin@123
 */
require_once __DIR__ . '/config/db.php';

$hash = password_hash('Admin@123', PASSWORD_DEFAULT);
$stmt = $pdo->prepare("UPDATE users SET password_hash = ? WHERE email = 'admin@ndspaper.com'");
$stmt->execute([$hash]);

echo "Admin password set. Login with admin@ndspaper.com / Admin@123 — now delete setup.php.";
