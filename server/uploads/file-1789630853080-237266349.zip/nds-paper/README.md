# NDS Paper

A web app for schools, colleges and coaching centres to build print-ready,
letterhead-branded question papers from uploaded question images.

Stack: **PHP + MySQL** backend, **HTML/CSS/vanilla JS** frontend, with
**Fabric.js** (canvas image editing), **SortableJS** (drag-reorder pages)
and **jsPDF** (client-side PDF export) loaded from a CDN.

---

## 1. Requirements

- PHP 8.0+ with the `pdo_mysql` extension
- MySQL 5.7+ / MariaDB 10.3+
- Apache or Nginx (Apache `.htaccess` is included for `/uploads`)
- Any standard LAMP/WAMP/XAMPP/MAMP stack works out of the box

## 2. Setup

1. Copy this whole folder into your web root, e.g. `htdocs/nds-paper`.
2. Create the database and tables:
   ```
   mysql -u root -p < database/schema.sql
   ```
3. Open `config/db.php` and set your DB host/user/password if they differ
   from the defaults (`root` / empty password / `localhost`).
4. Visit `http://localhost/nds-paper/setup.php` **once** in your browser —
   this sets the real bcrypt password hash for the seeded admin account.
   Then **delete `setup.php`** (or block it) for security.
5. Log in as the admin:
   - Email: `admin@ndspaper.com`
   - Password: `Admin@123`
   **Change this password immediately** from the admin dashboard's
   "Users & Credits" tab is for institute users only — for now, change the
   admin password by editing the `users` table directly, or add an
   admin-profile screen if you extend the app.
6. As admin: go to **Templates → + New template**, fill in the institute
   name/address/phone/logo, save it — you'll be taken straight into the
   **visual header designer** (`admin/template_editor.php`) where you drag
   the logo and text into place on an actual A4-width canvas and see
   exactly what page 1 will look like. Click **Save header design** when
   happy. Every user of that template will see this exact layout.
   You can reopen the designer any time from **Templates → Design header**.
7. Register a normal institute user (or create one from the admin panel),
   assign credits, and log in as that user to try the editor.

> Already imported the original schema before this feature existed?
> Run `database/migrations.sql` to add the new `header_layout` column.

## 3. Folder structure

```
nds-paper/
├── config/            DB connection + app constants
├── includes/          Auth + shared helper functions
├── database/schema.sql Full DB schema (run this first)
├── auth/               Login / register / logout
├── admin/              Admin dashboard, template & user management (AJAX)
├── user/               User dashboard + the question-paper editor
├── assets/             Shared CSS/JS/images for the public site
├── uploads/             Logos uploaded by admins (write-access needed)
└── generated/           Reserved for server-stored PDFs if you add that later
```

## 4. How the editor works

- Each uploaded image becomes one page.
- **Page 1** reserves a header band at the top, drawn from whatever the
  admin designed in **Admin → Templates → Design header** (a real
  drag-and-drop canvas, not a form) — logo position/size, institute name
  and address text all render on the user side pixel-for-pixel with what
  the admin saved, scaled proportionally if the user picks Letter/Legal
  instead of A4. The uploaded image is fitted into the remaining space
  below the header.
- **Pages 2+** have no header — the image is fitted across the full page.
- A footer strip with the page number and institute name is added to
  every page automatically.
- The right-hand panel now only appears as a small floating card when you
  actually select an image or the logo — it stays out of the way otherwise.
  It lets you adjust brightness, contrast, saturation, rotation, tilt
  (skew), flip and crop, and the **Layers** tab lets you re-order the logo
  vs. the question image and tune the logo's own brightness/contrast for
  that paper only. A **Delete** button removes the selected page/image.
- **Save** stores your entire progress (every image, position, crop,
  filter and the logo's tweaks) to your account — reopen it later from
  your dashboard's "Recent papers" list and everything is exactly as you
  left it, with nothing to re-upload.
- **Preview PDF** renders every page and opens it in a proper popup with
  an in-browser PDF viewer before you commit to anything.
- **Download** deducts 10 credits (server-side, atomic — see
  `user/ajax/deduct_credits.php`) and then saves the finished PDF.

> Note: cropping assumes the image hasn't been rotated yet — reset
> rotation to 0° before cropping for the most predictable result, then
> rotate afterwards if needed.

## 5. Credits system

- New institutes get 50 free credits on registration.
- Every credit change (top-up, revert, or a paper download) is written to
  `credit_transactions` so admins have a full audit trail.
- Admins can add credits, revert credits, edit user details/passwords,
  block/unblock, or delete users from **Admin → Users & Credits**.

## 6. Security notes for production

- Change the default admin password immediately.
- Serve the site over HTTPS.
- The `/uploads` folder blocks PHP execution via `.htaccess` — if you
  deploy on Nginx, add an equivalent rule in your server block.
- Consider adding rate limiting on `auth/login.php` if exposed publicly.

## 7. Notable fixes in this revision

- **Images are now uploaded as real files**, not embedded as base64 in the
  database. This is what was causing `SQLSTATE[08S01] ... max_allowed_packet`
  errors when saving a paper with several images — the JSON payload was
  simply too large for MySQL's packet limit. Images now live under
  `uploads/pages/<user_id>/` and only their URL is stored, so saved papers
  stay lightweight.
- **Credit checks are now server-authoritative.** The old client-side
  pre-check trusted a number set once at page load, which could go stale
  and show a confusing "insufficient credits" message even when the real
  balance was fine. The server now always checks and reports the *actual*
  current balance, and the Download button disables itself while a
  request is in flight to prevent double-charging from a double-click.
- **Preview no longer exposes a real PDF.** It used to embed an actual PDF
  in the browser's native viewer, whose own save/print icons let someone
  download the finished file without paying. Preview now renders a
  watermarked image gallery instead — the only way to get the real file is
  the paid Download button.
- **Fixed the header designer's missing styles** — it was using CSS classes
  that only existed in a stylesheet it never loaded, making its topbar
  nearly invisible. It's now self-contained and redirects back to the
  dashboard (with a confirmation banner) after saving.
- **Fixed the crop tool** — starting a crop was accidentally hiding the
  panel that contained the Apply/Cancel buttons.
- Added an **Opacity slider for the logo** (Layers tab) so it can be faded
  like a watermark; a logo's own transparent PNG background is preserved
  automatically regardless of this setting.
