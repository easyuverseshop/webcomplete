<?php
require_once __DIR__ . '/config/config.php';
if (is_logged_in()) {
    header('Location: ' . (is_admin() ? 'admin/dashboard.php' : 'user/dashboard.php'));
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>NDS Paper — Print-Ready Question Papers for Institutes</title>
<meta name="description" content="Create, brand and print professional question papers for your school, college or coaching centre in minutes.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Fraunces:wght@500;600;700&family=Inter:wght@400;500;600;700&family=IBM+Plex+Mono:wght@500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<header class="masthead">
  <div class="container">
    <div class="brand">
      <div class="mark">NDS <span>Paper</span></div>
      <div class="tagline">Institute Print Studio</div>
    </div>
    <nav class="nav-links">
      <a href="#features">Features</a>
      <a href="#process">How it works</a>
      <a href="#pricing">Credits</a>
      <a href="auth/login.php" class="btn btn-outline">Log in</a>
      <a href="auth/register.php" class="btn btn-stamp">Register institute</a>
    </nav>
  </div>
</header>

<section class="hero">
  <div class="container">
    <div>
      <div class="eyebrow">Question papers, letterhead-perfect, every time</div>
      <h1>Turn scanned questions into a print-ready paper in minutes.</h1>
      <p class="lede">Upload your question images, drop them onto your institute's branded template, fine-tune every page, and download an exam-ready PDF — complete with header, logo and footer on every sheet.</p>
      <div class="hero-actions">
        <a href="auth/register.php" class="btn btn-stamp">Register your institute</a>
        <a href="auth/login.php" class="btn btn-ghost">I already have an account</a>
      </div>
      <div class="hero-stats">
        <div><b>A4 / Letter</b><span>Paper sizes supported</span></div>
        <div><b>10 credits</b><span>Per finished download</span></div>
        <div><b>&lt; 5 min</b><span>Average paper turnaround</span></div>
      </div>
    </div>

    <div class="specimen-wrap">
      <div class="specimen-behind"></div>
      <div class="specimen">
        <div class="s-head">
          <div class="s-logo">N</div>
          <div>
            <div class="s-inst">Greenfield Public School</div>
            <div class="s-addr">12 MG Road, Gaya, Bihar &middot; +91 90000 00000</div>
          </div>
        </div>
        <div class="s-line w-90"></div>
        <div class="s-line w-70"></div>
        <div class="s-line w-90"></div>
        <div class="s-line w-50"></div>
        <div class="s-line w-90"></div>
        <div class="s-line w-70"></div>
      </div>
      <div class="badge-float">Page 1 of 6 &middot; Footer auto-added</div>
    </div>
  </div>
</section>

<hr class="rule">

<section id="features">
  <div class="container">
    <div class="section-head">
      <div class="eyebrow">Built for exam cells &amp; coaching desks</div>
      <h2>Everything from branding to bulk printing, handled.</h2>
    </div>
    <div class="grid-3">
      <div class="card">
        <div class="icon">Aa</div>
        <h3>Branded templates</h3>
        <p>Your admin saves the institute name, address, contact number and logo once — every paper any staff member creates carries it automatically.</p>
      </div>
      <div class="card">
        <div class="icon">✂</div>
        <h3>Full page editor</h3>
        <p>Drag, reorder, crop, rotate, tilt and adjust the brightness or colour of every uploaded question image before it goes to print.</p>
      </div>
      <div class="card">
        <div class="icon">⧉</div>
        <h3>Smart layout</h3>
        <p>The header only prints on page one — your remaining pages automatically fill edge-to-edge, and a footer with the page number and institute name is added throughout.</p>
      </div>
      <div class="card">
        <div class="icon">◈</div>
        <h3>Layer control</h3>
        <p>Manage the logo as its own layer — reposition it, resize it, or tune its brightness and contrast so it prints crisply on any photocopier.</p>
      </div>
      <div class="card">
        <div class="icon">▤</div>
        <h3>Live PDF preview</h3>
        <p>Check the finished, paginated PDF before you commit — see exactly what your teachers and students will receive.</p>
      </div>
      <div class="card">
        <div class="icon">₡</div>
        <h3>Simple credits</h3>
        <p>Institutes work on a prepaid credit system. Admins top-up, revert or review usage for every user from one dashboard.</p>
      </div>
    </div>
  </div>
</section>

<section class="section-alt" id="process">
  <div class="container">
    <div class="section-head">
      <div class="eyebrow">From upload to print</div>
      <h2>Four steps to a finished question paper.</h2>
    </div>
    <div class="process">
      <div class="step"><div class="num">1</div><h4>Pick a template</h4><p>Choose your institute's saved letterhead.</p></div>
      <div class="step"><div class="num">2</div><h4>Upload images</h4><p>Add your question images and drag to reorder.</p></div>
      <div class="step"><div class="num">3</div><h4>Fine-tune pages</h4><p>Crop, rotate and adjust each page precisely.</p></div>
      <div class="step"><div class="num">4</div><h4>Preview &amp; download</h4><p>Check the PDF, then download — 10 credits per paper.</p></div>
    </div>
  </div>
</section>

<section id="pricing">
  <div class="container">
    <div class="section-head">
      <div class="eyebrow">Transparent, prepaid</div>
      <h2>One flat cost — 10 credits per downloaded paper.</h2>
      <p>Your admin allocates credits to every registered user and can top-up or revert them at any time. No surprise charges, no subscriptions per page.</p>
    </div>
  </div>
</section>

<footer class="site-footer">
  <div class="container">
    <div>
      <div class="fbrand">NDS Paper</div>
      <small>&copy; <?= date('Y') ?> NDS Paper. Built for schools, colleges &amp; coaching centres.</small>
    </div>
    <div style="text-align:right">
      <a href="auth/login.php" style="display:block;margin-bottom:6px;">Log in</a>
      <a href="auth/register.php">Register</a>
    </div>
  </div>
</footer>

</body>
</html>
