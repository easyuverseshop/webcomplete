<?php
require_once __DIR__ . '/../config/config.php';
require_admin();

$id = (int) ($_GET['id'] ?? 0);
$stmt = $pdo->prepare('SELECT * FROM templates WHERE id = ?');
$stmt->execute([$id]);
$tpl = $stmt->fetch();
if (!$tpl) { header('Location: dashboard.php'); exit; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Design header — <?= h($tpl['name']) ?> — NDS Paper</title>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:wght@500;600;700&family=Inter:wght@400;500;600;700&family=IBM+Plex+Mono:wght@500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="assets/admin.css">
<link rel="stylesheet" href="assets/header-designer.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/fabric.js/5.3.0/fabric.min.js"></script>
</head>
<body class="hd-body">

<header class="hd-topbar">
  <div class="hd-topbar-left">
    <a href="dashboard.php" class="hd-back">&larr;</a>
    <div class="hd-title">Design header &mdash; <?= h($tpl['name']) ?></div>
  </div>
  <div class="hd-topbar-mid">
    This is exactly what page&nbsp;1 will look like for every user of this template.
  </div>
  <div class="hd-topbar-right">
    <button class="btn btn-ghost btn-sm" id="btnResetLayout">Reset to default</button>
    <button class="btn btn-ghost btn-sm" id="btnPreviewFull">Preview full page</button>
    <button class="btn btn-stamp btn-sm" id="btnSaveLayout">Save header design</button>
  </div>
</header>

<div class="hd-shell">
  <aside class="hd-side">
    <div class="hd-block">
      <h4>Elements</h4>
      <p class="hd-note">Click an element below, or click it directly on the header, then drag/resize it on the canvas. Use the controls to fine-tune.</p>
      <ul class="layer-list" id="hdLayerList">
        <li data-kind="logo">Logo</li>
        <li data-kind="institute">Institute name</li>
        <li data-kind="address">Address &amp; contact line</li>
      </ul>
    </div>

    <div class="hd-block" id="hdControls" style="display:none;">
      <h4>Selected element</h4>
      <div class="ctrl" id="ctrlFontSize">
        <label>Font size <span id="valFontSize">0</span>px</label>
        <input type="range" id="ctlFontSize" min="9" max="42" value="16">
      </div>
      <div class="ctrl" id="ctrlFontFamily">
        <label>Font</label>
        <select id="ctlFontFamily">
          <option value="Georgia, serif">Georgia (serif)</option>
          <option value="'Times New Roman', serif">Times New Roman</option>
          <option value="Arial, sans-serif">Arial</option>
          <option value="'Trebuchet MS', sans-serif">Trebuchet MS</option>
          <option value="'Courier New', monospace">Courier New</option>
        </select>
      </div>
      <div class="ctrl" id="ctrlStyle">
        <label>Style</label>
        <div class="ctrl-row">
          <button class="btn btn-ghost btn-sm" id="btnBold" type="button">Bold</button>
          <button class="btn btn-ghost btn-sm" id="btnItalic" type="button">Italic</button>
        </div>
      </div>
      <div class="ctrl" id="ctrlColor">
        <label>Text colour</label>
        <input type="color" id="ctlColor" value="#0F1B2D">
      </div>
      <div class="ctrl" id="ctrlAlign">
        <label>Text align</label>
        <select id="ctlAlign">
          <option value="left">Left</option>
          <option value="center">Center</option>
          <option value="right">Right</option>
        </select>
      </div>
      <p class="hd-note">Drag the element on the canvas to move it. Drag a corner handle to resize it.</p>
      <div class="ctrl-row">
        <button class="btn btn-ghost btn-sm" id="btnBringFront">Bring front</button>
        <button class="btn btn-ghost btn-sm" id="btnSendBack">Send back</button>
      </div>
    </div>

    <div class="hd-block">
      <h4>Header height</h4>
      <div class="ctrl">
        <label>Height (mm) <span id="valHeaderHeight"><?= (int) ($tpl['header_height_mm'] ?: 32) ?></span></label>
        <input type="range" id="ctlHeaderHeight" min="20" max="60" value="<?= (int) ($tpl['header_height_mm'] ?: 32) ?>">
      </div>
      <p class="hd-note">This is the space reserved above the question content on page 1 only.</p>
    </div>
  </aside>

  <main class="hd-stage">
    <div class="hd-canvas-card">
      <div class="hd-page-label">Page width shown at A4 scale &mdash; positions adapt automatically to Letter/Legal.</div>
      <div id="hdCanvasWrap" class="hd-canvas-wrap">
        <canvas id="hdCanvas"></canvas>
      </div>
      <div class="hd-fake-body">
        <div class="hd-fake-line" style="width:70%"></div>
        <div class="hd-fake-line" style="width:90%"></div>
        <div class="hd-fake-line" style="width:55%"></div>
        <div class="hd-fake-caption">&darr; Question images will appear in this space on page 1, full-bleed on every page after</div>
      </div>
    </div>
  </main>
</div>

<div class="modal-backdrop" id="fullPreviewModal">
  <div class="modal modal-lg">
    <div class="modal-head"><h2 style="font-size:1.1rem;margin:0;">Full page preview</h2><button class="close-x" data-close>&times;</button></div>
    <div class="modal-body" id="fullPreviewBody" style="background:#eee;text-align:center;padding:20px;"></div>
    <div class="modal-foot"><button type="button" class="btn btn-ghost" data-close>Close</button></div>
  </div>
</div>

<script>
  window.CSRF_TOKEN = "<?= csrf_token() ?>";
  window.TEMPLATE = <?= json_encode([
      'id' => (int) $tpl['id'],
      'name' => $tpl['name'],
      'institute_name' => $tpl['institute_name'],
      'address_line1' => $tpl['address_line1'],
      'address_line2' => $tpl['address_line2'],
      'phone' => $tpl['phone'],
      'logo_path' => $tpl['logo_path'] ? '../' . $tpl['logo_path'] : null,
      'header_height_mm' => (int) ($tpl['header_height_mm'] ?: 32),
      'header_layout' => $tpl['header_layout'] ? json_decode($tpl['header_layout']) : null,
  ]) ?>;
</script>
<script src="assets/header-designer.js"></script>
</body>
</html>
