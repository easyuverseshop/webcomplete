<?php
require_once __DIR__ . '/../../config/config.php';
header('Content-Type: application/json');

if (!is_admin()) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'Not authorized']);
    exit;
}

$action = $_GET['action'] ?? '';
$admin  = current_user();

function input(): array {
    if (!empty($_POST)) return $_POST;
    $raw = file_get_contents('php://input');
    return json_decode($raw, true) ?? [];
}

$data = input();
if ($action !== 'get' && !csrf_check($data['csrf'] ?? null)) {
    echo json_encode(['ok' => false, 'error' => 'Session expired, please refresh the page.']);
    exit;
}

try {
    if ($action === 'get') {
        $id = (int) ($_GET['id'] ?? 0);
        $stmt = $pdo->prepare('SELECT * FROM templates WHERE id = ?');
        $stmt->execute([$id]);
        $tpl = $stmt->fetch();
        echo json_encode($tpl ? ['ok' => true, 'template' => $tpl] : ['ok' => false, 'error' => 'Not found']);
        exit;
    }

    if ($action === 'create' || $action === 'update') {
        $name          = trim($data['name'] ?? '');
        $institute     = trim($data['institute_name'] ?? '');
        $addr1         = trim($data['address_line1'] ?? '');
        $addr2         = trim($data['address_line2'] ?? '');
        $phone         = trim($data['phone'] ?? '');

        if ($name === '' || $institute === '') {
            echo json_encode(['ok' => false, 'error' => 'Template name and institute name are required.']);
            exit;
        }

        $logoPath = null;
        if (!empty($_FILES['logo']['name'])) {
            $ext = strtolower(pathinfo($_FILES['logo']['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, ['png','jpg','jpeg','svg','webp'])) {
                echo json_encode(['ok' => false, 'error' => 'Logo must be an image file (png, jpg, webp, svg).']);
                exit;
            }
            $fname = 'logo_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
            move_uploaded_file($_FILES['logo']['tmp_name'], UPLOAD_DIR . '/logos/' . $fname);
            $logoPath = 'uploads/logos/' . $fname; // served relatively from app root
        }

        if ($action === 'create') {
            $stmt = $pdo->prepare(
                'INSERT INTO templates (name, institute_name, address_line1, address_line2, phone, logo_path, created_by)
                 VALUES (?,?,?,?,?,?,?)'
            );
            $stmt->execute([$name, $institute, $addr1, $addr2, $phone, $logoPath, $admin['id']]);
            $newId = (int) $pdo->lastInsertId();
            log_activity($pdo, $admin['id'], "Created template '$name'");
            echo json_encode(['ok' => true, 'id' => $newId]);
            exit;
        } else {
            $id = (int) ($data['id'] ?? 0);
            if ($logoPath) {
                $stmt = $pdo->prepare('UPDATE templates SET name=?, institute_name=?, address_line1=?, address_line2=?, phone=?, logo_path=? WHERE id=?');
                $stmt->execute([$name, $institute, $addr1, $addr2, $phone, $logoPath, $id]);
            } else {
                $stmt = $pdo->prepare('UPDATE templates SET name=?, institute_name=?, address_line1=?, address_line2=?, phone=? WHERE id=?');
                $stmt->execute([$name, $institute, $addr1, $addr2, $phone, $id]);
            }
            log_activity($pdo, $admin['id'], "Updated template #$id");
        }
        echo json_encode(['ok' => true]);
        exit;
    }

    if ($action === 'delete') {
        $id = (int) ($data['id'] ?? 0);
        $pdo->prepare('UPDATE templates SET status = "archived" WHERE id = ?')->execute([$id]);
        log_activity($pdo, $admin['id'], "Archived template #$id");
        echo json_encode(['ok' => true]);
        exit;
    }

    if ($action === 'save_layout') {
        $id = (int) ($data['id'] ?? 0);
        $layout = $data['layout'] ?? null;
        $headerHeightMm = (int) ($data['header_height_mm'] ?? 32);
        if (!$id || !is_array($layout)) {
            echo json_encode(['ok' => false, 'error' => 'Missing template id or layout data.']);
            exit;
        }
        $stmt = $pdo->prepare('UPDATE templates SET header_layout = ?, header_height_mm = ? WHERE id = ?');
        $stmt->execute([json_encode($layout), $headerHeightMm, $id]);
        log_activity($pdo, $admin['id'], "Saved header design for template #$id");
        echo json_encode(['ok' => true]);
        exit;
    }

    echo json_encode(['ok' => false, 'error' => 'Unknown action']);
} catch (Exception $e) {
    echo json_encode(['ok' => false, 'error' => 'Server error: ' . $e->getMessage()]);
}
