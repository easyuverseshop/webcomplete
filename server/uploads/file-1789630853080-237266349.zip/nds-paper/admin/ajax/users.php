<?php
require_once __DIR__ . '/../../config/config.php';
header('Content-Type: application/json');

if (!is_admin()) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'Not authorized']);
    exit;
}

$action = $_GET['action'] ?? '';
$admin  = current_user();

function body(): array {
    $raw = file_get_contents('php://input');
    return json_decode($raw, true) ?? [];
}

$data = ($action === 'get') ? [] : body();
if ($action !== 'get' && !csrf_check($data['csrf'] ?? null)) {
    echo json_encode(['ok' => false, 'error' => 'Session expired, please refresh the page.']);
    exit;
}

try {
    if ($action === 'get') {
        $id = (int) ($_GET['id'] ?? 0);
        $stmt = $pdo->prepare("SELECT id,name,email,phone,institute_name,credits,status FROM users WHERE id=? AND role='user'");
        $stmt->execute([$id]);
        $user = $stmt->fetch();
        echo json_encode($user ? ['ok' => true, 'user' => $user] : ['ok' => false, 'error' => 'Not found']);
        exit;
    }

    if ($action === 'create' || $action === 'update') {
        $name      = trim($data['name'] ?? '');
        $email     = trim($data['email'] ?? '');
        $phone     = trim($data['phone'] ?? '');
        $institute = trim($data['institute_name'] ?? '');
        $password  = $data['password'] ?? '';
        $credits   = max(0, (int) ($data['credits'] ?? 0));

        if ($name === '' || $email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo json_encode(['ok' => false, 'error' => 'A valid name and email are required.']);
            exit;
        }

        if ($action === 'create') {
            if (empty($password) || strlen($password) < 6) {
                echo json_encode(['ok' => false, 'error' => 'Password must be at least 6 characters.']);
                exit;
            }
            $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ?');
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                echo json_encode(['ok' => false, 'error' => 'A user with this email already exists.']);
                exit;
            }
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare('INSERT INTO users (name,email,phone,institute_name,password_hash,role,credits) VALUES (?,?,?,?,?,"user",?)');
            $stmt->execute([$name, $email, $phone, $institute, $hash, $credits]);
            $newId = (int) $pdo->lastInsertId();
            if ($credits > 0) {
                adjust_credits($pdo, $newId, $credits, 'Initial credits set by admin', $admin['id']);
            }
            log_activity($pdo, $admin['id'], "Created user '$email'");
        } else {
            $id = (int) ($data['id'] ?? 0);
            if (!empty($password)) {
                if (strlen($password) < 6) {
                    echo json_encode(['ok' => false, 'error' => 'Password must be at least 6 characters.']);
                    exit;
                }
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $pdo->prepare('UPDATE users SET name=?, email=?, phone=?, institute_name=?, password_hash=? WHERE id=?')
                    ->execute([$name, $email, $phone, $institute, $hash, $id]);
            } else {
                $pdo->prepare('UPDATE users SET name=?, email=?, phone=?, institute_name=? WHERE id=?')
                    ->execute([$name, $email, $phone, $institute, $id]);
            }
            log_activity($pdo, $admin['id'], "Updated user #$id");
        }
        echo json_encode(['ok' => true]);
        exit;
    }

    if ($action === 'delete') {
        $id = (int) ($data['id'] ?? 0);
        $pdo->prepare("DELETE FROM users WHERE id=? AND role='user'")->execute([$id]);
        log_activity($pdo, $admin['id'], "Deleted user #$id");
        echo json_encode(['ok' => true]);
        exit;
    }

    if ($action === 'status') {
        $id = (int) ($data['id'] ?? 0);
        $status = $data['status'] === 'blocked' ? 'blocked' : 'active';
        $pdo->prepare('UPDATE users SET status=? WHERE id=?')->execute([$status, $id]);
        log_activity($pdo, $admin['id'], "Set user #$id status to $status");
        echo json_encode(['ok' => true]);
        exit;
    }

    if ($action === 'credit') {
        $id     = (int) ($data['id'] ?? 0);
        $mode   = $data['mode'] ?? 'add';
        $amount = abs((int) ($data['amount'] ?? 0));
        $reason = trim($data['reason'] ?? '') ?: ($mode === 'add' ? 'Manual top-up by admin' : 'Manual revert by admin');

        if ($amount <= 0) {
            echo json_encode(['ok' => false, 'error' => 'Enter a valid amount.']);
            exit;
        }

        $signedAmount = $mode === 'add' ? $amount : -$amount;
        $success = adjust_credits($pdo, $id, $signedAmount, $reason, $admin['id']);
        if (!$success) {
            echo json_encode(['ok' => false, 'error' => 'Could not update credits (insufficient balance to revert, or user not found).']);
            exit;
        }
        log_activity($pdo, $admin['id'], "Adjusted credits for user #$id ($signedAmount)");
        echo json_encode(['ok' => true]);
        exit;
    }

    echo json_encode(['ok' => false, 'error' => 'Unknown action']);
} catch (Exception $e) {
    echo json_encode(['ok' => false, 'error' => 'Server error: ' . $e->getMessage()]);
}
