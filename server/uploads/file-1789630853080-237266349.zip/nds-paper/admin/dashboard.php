<?php
require_once __DIR__ . '/../config/config.php';
require_admin();

$totalUsers = (int) $pdo->query("SELECT COUNT(*) c FROM users WHERE role='user'")->fetch()['c'];
$totalTemplates = (int) $pdo->query("SELECT COUNT(*) c FROM templates WHERE status='active'")->fetch()['c'];
$totalPapers = (int) $pdo->query("SELECT COUNT(*) c FROM papers WHERE status='downloaded'")->fetch()['c'];
$creditsIssued = (int) $pdo->query("SELECT COALESCE(SUM(amount),0) c FROM credit_transactions WHERE amount > 0")->fetch()['c'];

$users = $pdo->query("SELECT id,name,email,institute_name,credits,status,created_at FROM users WHERE role='user' ORDER BY created_at DESC")->fetchAll();
$templates = $pdo->query("SELECT t.*, u.name AS creator FROM templates t JOIN users u ON u.id=t.created_by ORDER BY t.created_at DESC")->fetchAll();
$me = current_user();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard — NDS Paper</title>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:wght@500;600;700&family=Inter:wght@400;500;600;700&family=IBM+Plex+Mono:wght@500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="assets/admin.css">
</head>
<body>
<div class="app-shell">
  <aside class="sidebar">
    <div class="brand"><div class="mark">NDS <span style="color:var(--gold)">Paper</span></div></div>
    <nav class="side-nav">
      <a href="#overview" class="nav-link active" data-tab="overview">&#9635; Overview</a>
      <div class="grp-label">Manage</div>
      <a href="#templates" class="nav-link" data-tab="templates">&#9638; Templates</a>
      <a href="#users" class="nav-link" data-tab="users">&#9782; Users &amp; Credits</a>
    </nav>
    <div class="who">
      Signed in as<br><strong style="color:#fff;"><?= h($me['name']) ?></strong><br>
      <a href="../auth/logout.php">Log out</a>
    </div>
  </aside>

  <main class="main">
    <?php if (isset($_GET['header_saved'])): ?>
      <div class="flash-banner">Header design saved — every user of this template will now see this exact layout on page 1.</div>
    <?php endif; ?>
    <!-- OVERVIEW -->
    <section id="overview" class="tab-panel">
      <div class="topbar">
        <div><h1>Overview</h1><div class="sub">Everything happening across your institutes, at a glance.</div></div>
      </div>
      <div class="stat-grid">
        <div class="stat-card"><div class="label">Registered users</div><div class="value"><?= $totalUsers ?></div></div>
        <div class="stat-card"><div class="label">Active templates</div><div class="value"><?= $totalTemplates ?></div></div>
        <div class="stat-card"><div class="label">Papers downloaded</div><div class="value"><?= $totalPapers ?></div></div>
        <div class="stat-card"><div class="label">Credits issued</div><div class="value"><?= $creditsIssued ?></div></div>
      </div>
      <div class="panel">
        <div class="panel-head"><h2>Recently registered users</h2></div>
        <div class="panel-body" style="overflow-x:auto;">
          <table class="data">
            <thead><tr><th>Name</th><th>Institute</th><th>Email</th><th>Credits</th><th>Joined</th></tr></thead>
            <tbody>
              <?php foreach (array_slice($users, 0, 6) as $u): ?>
              <tr>
                <td><?= h($u['name']) ?></td>
                <td><?= h($u['institute_name']) ?></td>
                <td><?= h($u['email']) ?></td>
                <td><?= (int)$u['credits'] ?></td>
                <td><?= date('d M Y', strtotime($u['created_at'])) ?></td>
              </tr>
              <?php endforeach; ?>
              <?php if (!$users): ?><tr><td colspan="5" style="text-align:center;color:#6b7280;">No users yet.</td></tr><?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </section>

    <!-- TEMPLATES -->
    <section id="templates" class="tab-panel" style="display:none;">
      <div class="topbar">
        <div><h1>Templates</h1><div class="sub">The header, logo and address that print on every question paper.</div></div>
        <button class="btn btn-stamp" id="btnNewTemplate">+ New template</button>
      </div>
      <div class="panel">
        <div class="panel-body" style="overflow-x:auto;">
          <table class="data" id="templatesTable">
            <thead><tr><th>Logo</th><th>Name</th><th>Institute</th><th>Contact</th><th>Created by</th><th>Status</th><th></th></tr></thead>
            <tbody>
              <?php foreach ($templates as $t): ?>
              <tr data-id="<?= $t['id'] ?>">
                <td><img class="logo-preview" src="<?= $t['logo_path'] ? h($t['logo_path']) : '../assets/img/logo-placeholder.png' ?>" alt=""></td>
                <td><?= h($t['name']) ?></td>
                <td><?= h($t['institute_name']) ?><br><small style="color:#6b7280;"><?= h($t['address_line1']) ?></small></td>
                <td><?= h($t['phone']) ?></td>
                <td><?= h($t['creator']) ?></td>
                <td><span class="pill <?= $t['status']==='active'?'pill-active':'pill-blocked' ?>"><?= h($t['status']) ?></span></td>
                <td>
                  <div class="row-actions">
                    <a href="template_editor.php?id=<?= $t['id'] ?>" class="design-link">Design header</a>
                    <button class="btnEditTemplate" data-id="<?= $t['id'] ?>">Edit details</button>
                    <button class="danger btnDeleteTemplate" data-id="<?= $t['id'] ?>">Delete</button>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
              <?php if (!$templates): ?><tr><td colspan="7" style="text-align:center;color:#6b7280;">No templates yet — create your first one.</td></tr><?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </section>

    <!-- USERS -->
    <section id="users" class="tab-panel" style="display:none;">
      <div class="topbar">
        <div><h1>Users &amp; Credits</h1><div class="sub">Create, edit, block or fund every user on the platform.</div></div>
        <button class="btn btn-stamp" id="btnNewUser">+ New user</button>
      </div>
      <div class="panel">
        <div class="panel-body" style="overflow-x:auto;">
          <table class="data" id="usersTable">
            <thead><tr><th>Name</th><th>Institute</th><th>Email</th><th>Credits</th><th>Status</th><th></th></tr></thead>
            <tbody>
              <?php foreach ($users as $u): ?>
              <tr data-id="<?= $u['id'] ?>">
                <td><?= h($u['name']) ?></td>
                <td><?= h($u['institute_name']) ?></td>
                <td><?= h($u['email']) ?></td>
                <td class="cell-credits"><?= (int)$u['credits'] ?></td>
                <td class="cell-status"><span class="pill <?= $u['status']==='active'?'pill-active':'pill-blocked' ?>"><?= h($u['status']) ?></span></td>
                <td>
                  <div class="row-actions">
                    <button class="btnEditUser" data-id="<?= $u['id'] ?>">Edit</button>
                    <button class="btnCredit" data-id="<?= $u['id'] ?>" data-mode="add">+ Credits</button>
                    <button class="btnCredit" data-id="<?= $u['id'] ?>" data-mode="revert">- Revert</button>
                    <button class="btnToggleStatus" data-id="<?= $u['id'] ?>" data-status="<?= $u['status'] ?>"><?= $u['status']==='active' ? 'Block' : 'Unblock' ?></button>
                    <button class="danger btnDeleteUser" data-id="<?= $u['id'] ?>">Delete</button>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </section>
  </main>
</div>

<!-- Template modal -->
<div class="modal-backdrop" id="templateModal">
  <div class="modal">
    <div class="modal-head"><h2 id="templateModalTitle" style="font-size:1.1rem;margin:0;">New template</h2><button class="close-x" data-close>&times;</button></div>
    <form id="templateForm" enctype="multipart/form-data">
      <input type="hidden" name="id" id="tpl_id">
      <div class="modal-body">
        <div class="field"><label>Template name</label><input type="text" name="name" id="tpl_name" required placeholder="e.g. Mid-Term 2026"></div>
        <div class="field"><label>Institute name</label><input type="text" name="institute_name" id="tpl_institute" required></div>
        <div class="field"><label>Address line 1</label><input type="text" name="address_line1" id="tpl_addr1"></div>
        <div class="field"><label>Address line 2</label><input type="text" name="address_line2" id="tpl_addr2"></div>
        <div class="field"><label>Mobile number</label><input type="text" name="phone" id="tpl_phone"></div>
        <div class="field">
          <label>Logo</label>
          <label class="logo-drop" for="tpl_logo">Click to upload logo (PNG/JPG) — printed on every page</label>
          <input type="file" name="logo" id="tpl_logo" accept="image/*" style="display:none;">
        </div>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn btn-ghost" data-close>Cancel</button>
        <button type="submit" class="btn btn-stamp">Save template</button>
      </div>
    </form>
  </div>
</div>

<!-- User modal -->
<div class="modal-backdrop" id="userModal">
  <div class="modal">
    <div class="modal-head"><h2 id="userModalTitle" style="font-size:1.1rem;margin:0;">New user</h2><button class="close-x" data-close>&times;</button></div>
    <form id="userForm">
      <input type="hidden" name="id" id="usr_id">
      <div class="modal-body">
        <div class="field"><label>Name</label><input type="text" name="name" id="usr_name" required></div>
        <div class="field"><label>Institute name</label><input type="text" name="institute_name" id="usr_institute" required></div>
        <div class="field"><label>Email</label><input type="email" name="email" id="usr_email" required></div>
        <div class="field"><label>Phone</label><input type="text" name="phone" id="usr_phone"></div>
        <div class="field"><label id="pwLabel">Password (leave blank to keep unchanged)</label><input type="password" name="password" id="usr_password"></div>
        <div class="field"><label>Starting / current credits</label><input type="number" name="credits" id="usr_credits" min="0" value="0"></div>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn btn-ghost" data-close>Cancel</button>
        <button type="submit" class="btn btn-stamp">Save user</button>
      </div>
    </form>
  </div>
</div>

<!-- Credit modal -->
<div class="modal-backdrop" id="creditModal">
  <div class="modal">
    <div class="modal-head"><h2 id="creditModalTitle" style="font-size:1.1rem;margin:0;">Add credits</h2><button class="close-x" data-close>&times;</button></div>
    <form id="creditForm">
      <input type="hidden" name="id" id="cr_id"><input type="hidden" name="mode" id="cr_mode">
      <div class="modal-body">
        <div class="field"><label>Amount</label><input type="number" name="amount" id="cr_amount" min="1" required></div>
        <div class="field"><label>Reason / note</label><input type="text" name="reason" id="cr_reason" placeholder="e.g. Monthly top-up"></div>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn btn-ghost" data-close>Cancel</button>
        <button type="submit" class="btn btn-stamp">Confirm</button>
      </div>
    </form>
  </div>
</div>

<script>window.CSRF_TOKEN = "<?= csrf_token() ?>";</script>
<script src="assets/admin.js"></script>
</body>
</html>
