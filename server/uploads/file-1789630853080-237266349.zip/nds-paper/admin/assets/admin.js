document.addEventListener('DOMContentLoaded', () => {

  /* ---------- Tab switching ---------- */
  const navLinks = document.querySelectorAll('.nav-link');
  navLinks.forEach(link => {
    link.addEventListener('click', e => {
      e.preventDefault();
      navLinks.forEach(l => l.classList.remove('active'));
      link.classList.add('active');
      document.querySelectorAll('.tab-panel').forEach(p => p.style.display = 'none');
      document.getElementById(link.dataset.tab).style.display = 'block';
    });
  });

  /* ---------- Generic modal helpers ---------- */
  function openModal(id) { document.getElementById(id).classList.add('open'); }
  function closeModal(id) { document.getElementById(id).classList.remove('open'); }
  document.querySelectorAll('[data-close]').forEach(btn => {
    btn.addEventListener('click', () => btn.closest('.modal-backdrop').classList.remove('open'));
  });
  document.querySelectorAll('.modal-backdrop').forEach(bd => {
    bd.addEventListener('click', e => { if (e.target === bd) bd.classList.remove('open'); });
  });

  async function postJSON(url, data) {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...data, csrf: window.CSRF_TOKEN })
    });
    return res.json();
  }
  async function postForm(url, formData) {
    formData.append('csrf', window.CSRF_TOKEN);
    const res = await fetch(url, { method: 'POST', body: formData });
    return res.json();
  }

  /* ================= TEMPLATES ================= */
  const templateModal = 'templateModal';
  document.getElementById('btnNewTemplate').addEventListener('click', () => {
    document.getElementById('templateForm').reset();
    document.getElementById('tpl_id').value = '';
    document.getElementById('templateModalTitle').textContent = 'New template';
    openModal(templateModal);
  });

  document.querySelectorAll('.btnEditTemplate').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = btn.dataset.id;
      const r = await fetch('ajax/templates.php?action=get&id=' + id);
      const data = await r.json();
      if (!data.ok) return alert(data.error || 'Could not load template');
      const t = data.template;
      document.getElementById('tpl_id').value = t.id;
      document.getElementById('tpl_name').value = t.name;
      document.getElementById('tpl_institute').value = t.institute_name;
      document.getElementById('tpl_addr1').value = t.address_line1 || '';
      document.getElementById('tpl_addr2').value = t.address_line2 || '';
      document.getElementById('tpl_phone').value = t.phone || '';
      document.getElementById('templateModalTitle').textContent = 'Edit template';
      openModal(templateModal);
    });
  });

  document.querySelectorAll('.btnDeleteTemplate').forEach(btn => {
    btn.addEventListener('click', async () => {
      if (!confirm('Delete this template? Papers already created with it are unaffected.')) return;
      const data = await postJSON('ajax/templates.php?action=delete', { id: btn.dataset.id });
      if (data.ok) location.reload(); else alert(data.error || 'Delete failed');
    });
  });

  document.getElementById('templateForm').addEventListener('submit', async e => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const isNew = !fd.get('id');
    const action = isNew ? 'create' : 'update';
    const data = await postForm('ajax/templates.php?action=' + action, fd);
    if (!data.ok) return alert(data.error || 'Save failed');
    if (isNew && data.id) {
      window.location.href = 'template_editor.php?id=' + data.id;
    } else {
      location.reload();
    }
  });

  /* ================= USERS ================= */
  const userModal = 'userModal';
  document.getElementById('btnNewUser').addEventListener('click', () => {
    document.getElementById('userForm').reset();
    document.getElementById('usr_id').value = '';
    document.getElementById('pwLabel').textContent = 'Password';
    document.getElementById('usr_password').required = true;
    document.getElementById('userModalTitle').textContent = 'New user';
    openModal(userModal);
  });

  document.querySelectorAll('.btnEditUser').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = btn.dataset.id;
      const r = await fetch('ajax/users.php?action=get&id=' + id);
      const data = await r.json();
      if (!data.ok) return alert(data.error || 'Could not load user');
      const u = data.user;
      document.getElementById('usr_id').value = u.id;
      document.getElementById('usr_name').value = u.name;
      document.getElementById('usr_institute').value = u.institute_name || '';
      document.getElementById('usr_email').value = u.email;
      document.getElementById('usr_phone').value = u.phone || '';
      document.getElementById('usr_credits').value = u.credits;
      document.getElementById('pwLabel').textContent = 'Password (leave blank to keep unchanged)';
      document.getElementById('usr_password').required = false;
      document.getElementById('userModalTitle').textContent = 'Edit user';
      openModal(userModal);
    });
  });

  document.getElementById('userForm').addEventListener('submit', async e => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const payload = Object.fromEntries(fd.entries());
    const action = payload.id ? 'update' : 'create';
    const data = await postJSON('ajax/users.php?action=' + action, payload);
    if (data.ok) location.reload(); else alert(data.error || 'Save failed');
  });

  document.querySelectorAll('.btnDeleteUser').forEach(btn => {
    btn.addEventListener('click', async () => {
      if (!confirm('Delete this user permanently? This also removes their saved papers.')) return;
      const data = await postJSON('ajax/users.php?action=delete', { id: btn.dataset.id });
      if (data.ok) location.reload(); else alert(data.error || 'Delete failed');
    });
  });

  document.querySelectorAll('.btnToggleStatus').forEach(btn => {
    btn.addEventListener('click', async () => {
      const newStatus = btn.dataset.status === 'active' ? 'blocked' : 'active';
      const data = await postJSON('ajax/users.php?action=status', { id: btn.dataset.id, status: newStatus });
      if (data.ok) location.reload(); else alert(data.error || 'Update failed');
    });
  });

  /* ================= CREDITS ================= */
  document.querySelectorAll('.btnCredit').forEach(btn => {
    btn.addEventListener('click', () => {
      document.getElementById('cr_id').value = btn.dataset.id;
      document.getElementById('cr_mode').value = btn.dataset.mode;
      document.getElementById('creditModalTitle').textContent = btn.dataset.mode === 'add' ? 'Add credits' : 'Revert credits';
      document.getElementById('creditForm').reset();
      document.getElementById('cr_id').value = btn.dataset.id;
      document.getElementById('cr_mode').value = btn.dataset.mode;
      openModal('creditModal');
    });
  });

  document.getElementById('creditForm').addEventListener('submit', async e => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const payload = Object.fromEntries(fd.entries());
    const data = await postJSON('ajax/users.php?action=credit', payload);
    if (data.ok) location.reload(); else alert(data.error || 'Could not update credits');
  });

});
