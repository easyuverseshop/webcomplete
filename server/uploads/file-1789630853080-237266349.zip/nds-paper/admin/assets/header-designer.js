/* =========================================================
   NDS Paper — Admin Header Designer
   A WYSIWYG canvas so admins see exactly what page 1 will
   look like, before it's saved and reused on the user side.
   ========================================================= */

const PX_PER_MM = 96 / 25.4;
const A4_WIDTH_PX = Math.round(210 * PX_PER_MM);
const MARGIN_PX = Math.round(6 * PX_PER_MM);

const tpl = window.TEMPLATE;
let headerHeightMm = tpl.header_height_mm || 32;
let canvas = null;
let logoObj = null, instituteObj = null, addressObj = null;
let selectedKind = null;

function headerHeightPx() { return Math.round(headerHeightMm * PX_PER_MM); }

function defaultLayout() {
  return {
    canvasWidth: A4_WIDTH_PX,
    logo: { left: MARGIN_PX, top: 10, scaleX: null, scaleY: null },
    institute: { left: MARGIN_PX + 64, top: 12, fontSize: 22, fill: '#0F1B2D', textAlign: 'left', fontWeight: '700', fontStyle: 'normal', fontFamily: 'Georgia, serif' },
    address: { left: MARGIN_PX + 64, top: 40, fontSize: 11, fill: '#5b636b', textAlign: 'left', fontWeight: '400', fontStyle: 'normal', fontFamily: 'Arial, sans-serif' },
  };
}

function initCanvas() {
  canvas = new fabric.Canvas('hdCanvas', { backgroundColor: '#ffffff' });
  canvas.setWidth(A4_WIDTH_PX);
  canvas.setHeight(headerHeightPx());
  canvas.on('selection:created', onSelect);
  canvas.on('selection:updated', onSelect);
  canvas.on('selection:cleared', () => { selectedKind = null; document.getElementById('hdControls').style.display = 'none'; highlightList(); });
  buildFromLayout(tpl.header_layout || defaultLayout());
}

function buildFromLayout(layout) {
  canvas.clear();
  canvas.backgroundColor = '#ffffff';
  drawDivider();

  const addrParts = [tpl.address_line1, tpl.address_line2, tpl.phone].filter(Boolean).join('   |   ');

  instituteObj = new fabric.Textbox(tpl.institute_name || 'Institute name', {
    left: layout.institute.left, top: layout.institute.top, fontSize: layout.institute.fontSize,
    fill: layout.institute.fill, textAlign: layout.institute.textAlign, fontWeight: layout.institute.fontWeight,
    fontStyle: layout.institute.fontStyle || 'normal', fontFamily: layout.institute.fontFamily || 'Georgia, serif',
    width: A4_WIDTH_PX - MARGIN_PX - layout.institute.left, editableKind: 'institute',
  });
  canvas.add(instituteObj);

  addressObj = new fabric.Textbox(addrParts || 'Address line, phone number', {
    left: layout.address.left, top: layout.address.top, fontSize: layout.address.fontSize,
    fill: layout.address.fill, textAlign: layout.address.textAlign, fontStyle: layout.address.fontStyle || 'normal',
    fontFamily: layout.address.fontFamily || 'Arial, sans-serif',
    width: A4_WIDTH_PX - MARGIN_PX - layout.address.left, editableKind: 'address',
  });
  canvas.add(addressObj);

  if (tpl.logo_path) {
    fabric.Image.fromURL(tpl.logo_path, img => {
      const targetH = headerHeightPx() - 20;
      const scale = targetH / img.height;
      img.set({
        left: layout.logo.left, top: layout.logo.top,
        scaleX: layout.logo.scaleX || scale, scaleY: layout.logo.scaleY || scale,
        editableKind: 'logo',
      });
      canvas.add(img);
      logoObj = img;
      canvas.requestRenderAll();
    }, { crossOrigin: 'anonymous' });
  }
  canvas.requestRenderAll();
}

function drawDivider() {
  canvas.add(new fabric.Line([MARGIN_PX, headerHeightPx() - 6, A4_WIDTH_PX - MARGIN_PX, headerHeightPx() - 6], {
    stroke: '#0F1B2D', strokeWidth: 2, selectable: false, evented: false,
  }));
}

function onSelect(e) {
  const obj = e.selected ? e.selected[0] : canvas.getActiveObject();
  if (!obj || !obj.editableKind) return;
  selectedKind = obj.editableKind;
  document.getElementById('hdControls').style.display = 'block';
  const isText = selectedKind !== 'logo';
  ['ctrlFontSize', 'ctrlFontFamily', 'ctrlStyle', 'ctrlColor', 'ctrlAlign'].forEach(id => {
    document.getElementById(id).style.display = isText ? 'block' : 'none';
  });
  if (isText) {
    document.getElementById('ctlFontSize').value = obj.fontSize;
    document.getElementById('valFontSize').textContent = obj.fontSize;
    document.getElementById('ctlFontFamily').value = obj.fontFamily || 'Georgia, serif';
    document.getElementById('ctlColor').value = rgbToHex(obj.fill);
    document.getElementById('ctlAlign').value = obj.textAlign;
    document.getElementById('btnBold').classList.toggle('active-style', obj.fontWeight === '700' || obj.fontWeight === 'bold');
    document.getElementById('btnItalic').classList.toggle('active-style', obj.fontStyle === 'italic');
  }
  highlightList();
}

function rgbToHex(c) {
  if (!c) return '#0F1B2D';
  if (c.startsWith('#')) return c;
  return '#0F1B2D';
}

function getObjByKind(kind) {
  return kind === 'logo' ? logoObj : kind === 'institute' ? instituteObj : addressObj;
}

document.querySelectorAll('#hdLayerList li').forEach(li => {
  li.addEventListener('click', () => {
    const obj = getObjByKind(li.dataset.kind);
    if (!obj) return alert('No logo has been uploaded for this template yet — add one by editing the template first.');
    canvas.setActiveObject(obj);
    canvas.requestRenderAll();
  });
});
function highlightList() {
  document.querySelectorAll('#hdLayerList li').forEach(li => li.classList.toggle('selected', li.dataset.kind === selectedKind));
}

document.getElementById('ctlFontSize').addEventListener('input', e => {
  document.getElementById('valFontSize').textContent = e.target.value;
  const obj = getObjByKind(selectedKind);
  if (obj && selectedKind !== 'logo') { obj.set({ fontSize: Number(e.target.value) }); canvas.requestRenderAll(); }
});
document.getElementById('ctlColor').addEventListener('input', e => {
  const obj = getObjByKind(selectedKind);
  if (obj && selectedKind !== 'logo') { obj.set({ fill: e.target.value }); canvas.requestRenderAll(); }
});
document.getElementById('ctlAlign').addEventListener('change', e => {
  const obj = getObjByKind(selectedKind);
  if (obj && selectedKind !== 'logo') { obj.set({ textAlign: e.target.value }); canvas.requestRenderAll(); }
});
document.getElementById('ctlFontFamily').addEventListener('change', e => {
  const obj = getObjByKind(selectedKind);
  if (obj && selectedKind !== 'logo') { obj.set({ fontFamily: e.target.value }); canvas.requestRenderAll(); }
});
document.getElementById('btnBold').addEventListener('click', () => {
  const obj = getObjByKind(selectedKind);
  if (!obj || selectedKind === 'logo') return;
  const isBold = obj.fontWeight === '700' || obj.fontWeight === 'bold';
  obj.set({ fontWeight: isBold ? '400' : '700' });
  document.getElementById('btnBold').classList.toggle('active-style', !isBold);
  canvas.requestRenderAll();
});
document.getElementById('btnItalic').addEventListener('click', () => {
  const obj = getObjByKind(selectedKind);
  if (!obj || selectedKind === 'logo') return;
  const isItalic = obj.fontStyle === 'italic';
  obj.set({ fontStyle: isItalic ? 'normal' : 'italic' });
  document.getElementById('btnItalic').classList.toggle('active-style', !isItalic);
  canvas.requestRenderAll();
});
document.getElementById('btnBringFront').addEventListener('click', () => { const o = getObjByKind(selectedKind); if (o) canvas.bringToFront(o); });
document.getElementById('btnSendBack').addEventListener('click', () => { const o = getObjByKind(selectedKind); if (o) canvas.sendToBack(o); });

document.getElementById('ctlHeaderHeight').addEventListener('input', e => {
  headerHeightMm = Number(e.target.value);
  document.getElementById('valHeaderHeight').textContent = headerHeightMm;
  canvas.setHeight(headerHeightPx());
  buildFromLayout(collectLayout());
});

document.getElementById('btnResetLayout').addEventListener('click', () => {
  if (!confirm('Reset the header to the default layout? Unsaved changes will be lost.')) return;
  buildFromLayout(defaultLayout());
});

function collectLayout() {
  return {
    canvasWidth: A4_WIDTH_PX,
    logo: logoObj ? { left: logoObj.left, top: logoObj.top, scaleX: logoObj.scaleX, scaleY: logoObj.scaleY } : null,
    institute: { left: instituteObj.left, top: instituteObj.top, fontSize: instituteObj.fontSize, fill: instituteObj.fill, textAlign: instituteObj.textAlign, fontWeight: instituteObj.fontWeight || '700', fontStyle: instituteObj.fontStyle || 'normal', fontFamily: instituteObj.fontFamily || 'Georgia, serif' },
    address: { left: addressObj.left, top: addressObj.top, fontSize: addressObj.fontSize, fill: addressObj.fill, textAlign: addressObj.textAlign, fontWeight: addressObj.fontWeight || '400', fontStyle: addressObj.fontStyle || 'normal', fontFamily: addressObj.fontFamily || 'Arial, sans-serif' },
  };
}

document.getElementById('btnSaveLayout').addEventListener('click', async () => {
  canvas.discardActiveObject();
  canvas.requestRenderAll();
  const layout = collectLayout();
  const btn = document.getElementById('btnSaveLayout');
  btn.disabled = true; btn.textContent = 'Saving…';
  const res = await fetch('ajax/templates.php?action=save_layout', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ csrf: window.CSRF_TOKEN, id: tpl.id, layout, header_height_mm: headerHeightMm }),
  });
  const data = await res.json();
  if (data.ok) {
    window.location.href = 'dashboard.php?header_saved=1';
  } else {
    alert(data.error || 'Could not save the header design.');
    btn.disabled = false; btn.textContent = 'Save header design';
  }
});

document.getElementById('btnPreviewFull').addEventListener('click', () => {
  canvas.discardActiveObject();
  canvas.requestRenderAll();
  const headerDataUrl = canvas.toDataURL({ format: 'png', multiplier: 1.5 });
  const pageHeightPx = Math.round(297 * PX_PER_MM);
  const bodyHeight = pageHeightPx - headerHeightPx() - Math.round(10 * PX_PER_MM);
  document.getElementById('fullPreviewBody').innerHTML = `
    <div style="background:#fff;width:${A4_WIDTH_PX}px;margin:0 auto;box-shadow:0 4px 20px rgba(0,0,0,.2);">
      <img src="${headerDataUrl}" style="display:block;width:100%;">
      <div style="height:${bodyHeight}px;border:2px dashed #D8D2C4;margin:14px;display:flex;align-items:center;justify-content:center;color:#b6bac0;font-size:.85rem;">
        Question images will fill this area on page 1
      </div>
      <div style="border-top:1px solid #D8D2C4;padding:8px 20px;font-size:11px;color:#5b636b;display:flex;justify-content:space-between;">
        <span>${tpl.institute_name || ''}</span><span>Page 1 of N</span>
      </div>
    </div>`;
  document.getElementById('fullPreviewModal').classList.add('open');
});

document.querySelectorAll('[data-close]').forEach(btn => btn.addEventListener('click', () => btn.closest('.modal-backdrop').classList.remove('open')));
document.querySelectorAll('.modal-backdrop').forEach(bd => bd.addEventListener('click', e => { if (e.target === bd) bd.classList.remove('open'); }));

initCanvas();
